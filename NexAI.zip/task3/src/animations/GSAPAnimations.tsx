import { type ReactNode, useEffect, useRef } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

export function Marquee({ children, speed = 1 }: { children: ReactNode; speed?: number }) {
  const containerRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = containerRef.current
    if (!el) return

    const width = el.scrollWidth / 2
    gsap.to(el, {
      x: -width,
      duration: 30 / speed,
      repeat: -1,
      ease: 'none',
    })
  }, [speed])

  return (
    <div className="overflow-hidden pointer-events-none select-none">
      <div ref={containerRef} className="flex gap-8 w-max">
        {children}
        {children}
      </div>
    </div>
  )
}

export function ParallaxSection({ children, speed = 0.2 }: { children: ReactNode; speed?: number }) {
  const ref = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    gsap.to(el, {
      y: `${speed * 100}%`,
      ease: 'none',
      scrollTrigger: {
        trigger: el,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
      },
    })
  }, [speed])

  return <div ref={ref}>{children}</div>
}