export interface NavItem {
  id: string
  label: string
  href: string
}

export interface Stat {
  value: number
  suffix: string
  label: string
}

export interface Company {
  name: string
  logo: string
}

export interface Feature {
  id: string
  title: string
  description: string
  icon: string
  gradient: string
  illustration?: string
  details: string[]
}

export interface PricingPlan {
  id: string
  name: string
  description: string
  monthlyPrice: number
  yearlyPrice: number
  popular: boolean
  features: { name: string; included: boolean }[]
  cta: string
  gradient: string
}

export interface Testimonial {
  id: string
  name: string
  role: string
  company: string
  avatar: string
  content: string
  rating: number
}

export interface FAQ {
  id: string
  question: string
  answer: string
  category: string
}

export interface BlogPost {
  id: string
  title: string
  excerpt: string
  image: string
  category: string
  author: string
  authorAvatar: string
  date: string
  readingTime: string
}

export interface ComparisonFeature {
  id: string
  name: string
  plans: { name: string; included: boolean | string }[]
  tooltip?: string
}

export interface ContactFormData {
  name: string
  email: string
  subject: string
  message: string
}

export type Theme = 'light' | 'dark'
export type AccentColor = 'violet' | 'blue' | 'green' | 'rose' | 'amber'
export type Language = 'en' | 'es' | 'fr' | 'de' | 'ja' | 'zh'