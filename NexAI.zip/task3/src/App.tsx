import { Suspense, lazy } from 'react'
import { ThemeProvider } from '@/context/ThemeContext'
import { LanguageProvider } from '@/context/LanguageContext'
import { Navbar } from '@/components/layout/Navbar'
import { BackToTop } from '@/components/layout/BackToTop'
import { CustomCursor } from '@/components/effects/CustomCursor'
import { ThreeDScene } from '@/components/effects/ThreeDScene'
import { LoadingScreen } from '@/components/ui/Skeleton'
import { ScrollProgressBar } from '@/components/layout/ScrollProgressBar'
import { ThemeCustomizer } from '@/components/effects/ThemeCustomizer'
import { LanguageSwitcher } from '@/components/effects/LanguageSwitcher'
import { ChatWidget } from '@/components/effects/ChatWidget'
import { useLenis } from '@/hooks/useLenis'

const Hero = lazy(() => import('@/sections/Hero'))
const Features = lazy(() => import('@/sections/Features'))
const Showcase = lazy(() => import('@/sections/Showcase'))
const Pricing = lazy(() => import('@/sections/Pricing'))
const Comparison = lazy(() => import('@/sections/Comparison'))
const Testimonials = lazy(() => import('@/sections/Testimonials'))
const FAQ = lazy(() => import('@/sections/FAQ'))
const Blog = lazy(() => import('@/sections/Blog'))
const Contact = lazy(() => import('@/sections/Contact'))
const Footer = lazy(() => import('@/sections/Footer'))

function Loading() {
  return <div className="h-96 flex items-center justify-center"><div className="w-6 h-6 rounded-full border-2 border-nova-500 border-t-transparent animate-spin" /></div>
}

function HomePage() {
  useLenis()
  return (
    <main className="relative z-10">
      <Suspense fallback={<Loading />}><Hero /></Suspense>
      <Suspense fallback={<Loading />}><Features /></Suspense>
      <Suspense fallback={<Loading />}><Showcase /></Suspense>
      <Suspense fallback={<Loading />}><Pricing /></Suspense>
      <Suspense fallback={<Loading />}><Comparison /></Suspense>
      <Suspense fallback={<Loading />}><Testimonials /></Suspense>
      <Suspense fallback={<Loading />}><FAQ /></Suspense>
      <Suspense fallback={<Loading />}><Blog /></Suspense>
      <Suspense fallback={<Loading />}><Contact /></Suspense>
      <Suspense fallback={<Loading />}><Footer /></Suspense>
    </main>
  )
}

export default function App() {
  return (
    <ThemeProvider>
      <LanguageProvider>
        <ThreeDScene />
        <LoadingScreen />
        <CustomCursor />
        <Navbar />
        <ScrollProgressBar />
        <HomePage />
        <ThemeCustomizer />
        <LanguageSwitcher />
        <ChatWidget />
        <BackToTop />
      </LanguageProvider>
    </ThemeProvider>
  )
}