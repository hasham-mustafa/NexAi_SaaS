import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useTheme } from '@/context/ThemeContext'
import type { AccentColor } from '@/types'
import { Palette } from 'lucide-react'

const accentColors: { name: AccentColor; gradient: string }[] = [
  { name: 'violet', gradient: 'from-violet-500 to-purple-600' },
  { name: 'blue', gradient: 'from-blue-500 to-cyan-600' },
  { name: 'green', gradient: 'from-emerald-500 to-teal-600' },
  { name: 'rose', gradient: 'from-rose-500 to-pink-600' },
  { name: 'amber', gradient: 'from-amber-500 to-orange-600' },
]

export function ThemeCustomizer() {
  const [isOpen, setIsOpen] = useState(false)
  const { theme, accentColor, setTheme, setAccentColor } = useTheme()

  return (
    <>
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        whileHover={{ scale: 1.05 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-20 z-40 w-10 h-10 rounded-xl bg-foreground/5 flex items-center justify-center text-foreground/60 hover:text-foreground hover:bg-foreground/10 transition-all backdrop-blur-lg"
        aria-label="Theme settings"
      >
        <Palette size={18} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="fixed bottom-20 right-20 z-40 glass-card rounded-2xl p-4 shadow-2xl w-56"
          >
            <div className="space-y-4">
              <div>
                <h4 className="text-xs font-semibold text-foreground/60 uppercase tracking-wider mb-2">Theme</h4>
                <div className="flex gap-2">
                  <button onClick={() => setTheme('light')} className={`flex-1 h-8 rounded-xl text-xs font-medium transition-all ${theme === 'light' ? 'bg-nova-600 text-white shadow-lg shadow-nova-500/25' : 'glass text-foreground/60'}`}>Light</button>
                  <button onClick={() => setTheme('dark')} className={`flex-1 h-8 rounded-xl text-xs font-medium transition-all ${theme === 'dark' ? 'bg-nova-600 text-white shadow-lg shadow-nova-500/25' : 'glass text-foreground/60'}`}>Dark</button>
                </div>
              </div>
              <div>
                <h4 className="text-xs font-semibold text-foreground/60 uppercase tracking-wider mb-2">Accent</h4>
                <div className="flex gap-2">
                  {accentColors.map(({ name, gradient }) => (
                    <button key={name} onClick={() => setAccentColor(name)} className={`w-7 h-7 rounded-lg bg-gradient-to-br ${gradient} transition-all ${accentColor === name ? 'ring-2 ring-offset-2 ring-nova-500 scale-110' : 'opacity-60 hover:opacity-100'}`} aria-label={`Set accent to ${name}`} />
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}