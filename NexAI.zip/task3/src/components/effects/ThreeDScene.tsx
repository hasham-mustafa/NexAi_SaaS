import { useRef, useEffect, useMemo, type MutableRefObject } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import * as THREE from 'three'

/* ------------------------------------------------------------------ */
/*  Per-section shape & scene configuration                           */
/* ------------------------------------------------------------------ */

const SECTION_IDS = [
  'home', 'features', 'showcase', 'pricing', 'comparison',
  'testimonials', 'faq', 'blog', 'contact',
]

const SECTION_HUES: number[] = [265, 225, 195, 155, 215, 335, 42, 22, 245]

type ShapeFn = (nx: number, ny: number, nz: number, t: number) => number

const SHAPES: ShapeFn[] = [
  /* 0 home       – smooth sphere with gentle pulse */ (n, y, z, t) =>
    1 + 0.12 * Math.sin((n + y + z) * 2 + t * 0.8) + 0.06 * Math.sin(t * 0.4),

  /* 1 features   – crystalline facets */ (n, y, z, t) => {
    const a = Math.abs(n) + Math.abs(y) + Math.abs(z)
    return 1 + 0.35 * Math.sin(a * 5 + t * 0.5) + 0.1 * Math.sin(a * 10 + t)
  },

  /* 2 showcase   – twisted helix */ (n, y, z, t) =>
    1 + 0.25 * Math.sin(n * 3 + y * 2 + t * 0.6) + 0.18 * Math.cos(z * 4 + t * 0.3) + 0.08 * Math.sin(y * 6 + t),

  /* 3 pricing    – flattened disc */ (n, y, z, t) =>
    1 + 0.3 * Math.sin(y * 5 + t * 0.4) + 0.2 * y * y + 0.08 * Math.sin((n + z) * 4 + t),

  /* 4 comparison – cubic / structured */ (n, y, z, t) => {
    const c = Math.max(Math.abs(n), Math.abs(y), Math.abs(z))
    return 0.85 + 0.2 * Math.sin(c * 8 + t * 0.3) + 0.08 * Math.sin(t * 0.5)
  },

  /* 5 testimonials – organic / petal */ (n, y, z, t) =>
    1 + 0.35 * Math.sin((n * n + z * z) * 6 + t * 0.5) + 0.1 * Math.sin(y * 4 + t),

  /* 6 faq        – torus / ring */ (n, y, z, t) => {
    const d = Math.sqrt(n * n + z * z)
    return 1 + 0.4 * Math.sin(d * 7 + t * 0.4) + 0.1 * Math.sin(y * 3 + t * 0.6)
  },

  /* 7 blog       – spiky / star */ (n, y, z, t) => {
    const s = Math.abs(n) + Math.abs(y) + Math.abs(z)
    return 1 + 0.45 * Math.sin(s * 6 + t * 0.7) + 0.12 * Math.sin(s * 12 + t * 1.2)
  },

  /* 8 contact    – diamond / octahedron */ (n, y, z, t) => {
    const f = 1 - Math.abs(y) * 0.6
    return f + 0.25 * Math.sin(n * 5 + z * 5 + t * 0.3) + 0.06 * Math.sin(t * 0.7)
  },
]

const RIBBON_PROPS: { amp: number; freq: number; twist: number }[] = [
  { amp: 1.2, freq: 2, twist: 1.5 },
  { amp: 1.8, freq: 3, twist: 1.8 },
  { amp: 1.5, freq: 2.5, twist: 2.2 },
  { amp: 0.8, freq: 1.5, twist: 1.0 },
  { amp: 1.4, freq: 3.5, twist: 1.6 },
  { amp: 2.0, freq: 2, twist: 1.2 },
  { amp: 1.1, freq: 4, twist: 1.9 },
  { amp: 1.6, freq: 2.8, twist: 2.5 },
  { amp: 1.3, freq: 3.2, twist: 1.4 },
]

const PARTICLE_SPEEDS: number[] = [
  0.003, 0.005, 0.004, 0.002, 0.0045, 0.0035, 0.0055, 0.006, 0.003,
]

/* ------------------------------------------------------------------ */
/*  Scene state (shared across all 3D elements via ref)               */
/* ------------------------------------------------------------------ */

interface SceneState {
  hue: number
  scroll: number
  currentIdx: number
  targetIdx: number
  morphP: number        // 0→1 morph progress toward target shape
  morphFlash: number    // brief pulse on transition
  prevTargetIdx: number // previous target for edge detection
}

function createSceneState(): SceneState {
  return { hue: 265, scroll: 0, currentIdx: 0, targetIdx: 0, morphP: 1, morphFlash: 0, prevTargetIdx: 0 }
}

/* ------------------------------------------------------------------ */
/*  Blob – morphs between per-section shapes                           */
/* ------------------------------------------------------------------ */

function Blob({
  position, scale = 1, speed = 1, stateRef, shapeIdx, morphDir = 1,
}: {
  position: [number, number, number]
  scale?: number
  speed?: number
  stateRef: MutableRefObject<SceneState>
  shapeIdx: number // which shape index to track (0, 1, or 2 for the 3 blobs)
}) {
  const meshRef = useRef<THREE.Mesh>(null!)
  const geoRef = useRef<THREE.BufferGeometry>(null!)
  const normsRef = useRef<Float32Array | null>(null)

  const material = useMemo(() => new THREE.MeshPhysicalMaterial({
    roughness: 0.12,
    metalness: 0.05,
    clearcoat: 1,
    clearcoatRoughness: 0.1,
    transparent: true,
    opacity: 0.55,
  }), [])

  const geometry = useMemo(() => {
    const g = new THREE.IcosahedronGeometry(1, 4)
    const base = g.attributes.position.array as Float32Array
    const norms = new Float32Array(base.length)
    for (let i = 0; i < base.length; i += 3) {
      const x = base[i], y = base[i + 1], z = base[i + 2]
      const len = Math.sqrt(x * x + y * y + z * z)
      norms[i] = x / len; norms[i + 1] = y / len; norms[i + 2] = z / len
    }
    normsRef.current = norms
    return g
  }, [])

  useFrame((state) => {
    const t = state.clock.elapsedTime * speed
    const s = stateRef.current
    const hue = s.hue

    if (normsRef.current && geoRef.current) {
      const pos = geoRef.current.attributes.position.array as Float32Array
      const n = normsRef.current
      const pIdx = s.currentIdx
      const pNext = s.targetIdx
      const blend = Math.max(0, Math.min(1, s.morphP))

      // Add a wave that sweeps across the shape during morph
      const waveOffset = shapeIdx * 2.1 + position[0] * 0.3

      for (let i = 0; i < pos.length; i += 3) {
        const nx = n[i], ny = n[i + 1], nz = n[i + 2]

        // Current shape radius
        const r1 = SHAPES[pIdx](nx, ny, nz, t)
        // Next shape radius
        const r2 = SHAPES[pNext](nx, ny, nz, t + (1 - blend) * 0.5)

        // Morph wave: transition sweeps across the surface
        const vertexPhase = (nx * morphDir + ny * 0.4 + nz * 0.3) * 0.5 + 0.5
        const waveStart = blend
        const waveWidth = 0.35
        const localBlend = Math.max(0, Math.min(1,
          (blend - vertexPhase * waveWidth + waveWidth) / (waveWidth * 2)
        ))
        const easedBlend = localBlend * localBlend * (3 - 2 * localBlend)

        const r = r1 * (1 - easedBlend) + r2 * easedBlend
        pos[i] = nx * r; pos[i + 1] = ny * r; pos[i + 2] = nz * r
      }
      geoRef.current.attributes.position.needsUpdate = true
      geoRef.current.computeVertexNormals()
    }

    // Color
    const c = new THREE.Color().setHSL(hue / 360, 0.4, 0.55 + 0.12 * Math.sin(t * 0.4))
    material.color.copy(c)
    material.emissive.copy(c).multiplyScalar(0.1 + s.morphFlash * 0.2)
    material.opacity = 0.35 + 0.15 * Math.sin(t * 0.25)

    // Position & rotation
    meshRef.current.position.y = position[1] +
      Math.sin(t * 0.18 + position[0]) * 0.4 -
      s.scroll * 2.5
    meshRef.current.rotation.x = t * 0.08 + s.morphFlash * 0.3
    meshRef.current.rotation.z = t * 0.06 + s.morphFlash * 0.2
    // Scale pulse on morph
    const pulse = 1 + s.morphFlash * 0.08
    meshRef.current.scale.setScalar(scale * pulse)
  })

  return <mesh ref={meshRef} position={position} geometry={geometry} material={material} />
}

/* ------------------------------------------------------------------ */
/*  Glass sphere                                                       */
/* ------------------------------------------------------------------ */
function GlassSphere({
  position, scale = 1, stateRef,
}: {
  position: [number, number, number]
  scale?: number
  stateRef: MutableRefObject<SceneState>
}) {
  const meshRef = useRef<THREE.Mesh>(null!)

  const material = useMemo(() => new THREE.MeshPhysicalMaterial({
    transmission: 0.92, thickness: 1.2, roughness: 0, metalness: 0,
    ior: 1.45, envMapIntensity: 2.5, clearcoat: 1,
    transparent: true, opacity: 0.85,
  }), [])

  useFrame((state) => {
    const t = state.clock.elapsedTime
    const s = stateRef.current
    const c = new THREE.Color().setHSL(s.hue / 360, 0.25, 0.85)
    material.color.copy(c)
    meshRef.current.position.y = position[1] +
      Math.sin(t * 0.3 + position[0]) * 0.25 -
      s.scroll * 1.5
    const pulse = 1 + s.morphFlash * 0.04
    meshRef.current.scale.setScalar(scale * pulse)
  })

  return (
    <mesh ref={meshRef} position={position}>
      <sphereGeometry args={[0.65, 48, 48]} />
      <primitive object={material} attach="material" />
    </mesh>
  )
}

/* ------------------------------------------------------------------ */
/*  Ribbon – rebuilds curve per section                                */
/* ------------------------------------------------------------------ */
function Ribbon({
  stateRef, offset = 0,
}: {
  stateRef: MutableRefObject<SceneState>
  offset?: number
}) {
  const meshRef = useRef<THREE.Mesh>(null!)

  const material = useMemo(() => new THREE.MeshPhysicalMaterial({
    transparent: true, opacity: 0.15, roughness: 0.2, metalness: 0,
    side: THREE.DoubleSide, blending: THREE.AdditiveBlending, depthWrite: false,
  }), [])

  const lastSection = useRef(-1)

  useFrame((state) => {
    const t = state.clock.elapsedTime
    const s = stateRef.current

    // Rebuild geometry only when section index changes
    const idx = s.targetIdx
    if (idx !== lastSection.current) {
      lastSection.current = idx
      const p = RIBBON_PROPS[idx]
      const pts: THREE.Vector3[] = []
      const segments = 24
      for (let i = 0; i <= segments; i++) {
        const rt = i / segments
        pts.push(new THREE.Vector3(
          (rt - 0.5) * 6,
          Math.sin(rt * Math.PI * p.freq + offset) * p.amp,
          Math.cos(rt * Math.PI * p.twist + offset) * 0.5,
        ))
      }
      const curve = new THREE.CatmullRomCurve3(pts)
      const newGeo = new THREE.TubeGeometry(curve, 80, 0.035, 6, false)
      if (meshRef.current.geometry) meshRef.current.geometry.dispose()
      meshRef.current.geometry = newGeo
    }

    const hue = s.hue
    const shift = Math.sin(t * 0.12 + offset) * 0.4
    const c = new THREE.Color().setHSL((hue + shift * 20) / 360, 0.35, 0.55)
    material.color.copy(c)
    material.emissive.copy(c).multiplyScalar(0.06)
    meshRef.current.position.y = Math.sin(t * 0.08 + offset) * 0.2 - s.scroll * 1.8
    meshRef.current.rotation.z = Math.sin(t * 0.06 + offset) * 0.04
  })

  return <mesh ref={meshRef} material={material} />
}

/* ------------------------------------------------------------------ */
/*  Particles                                                          */
/* ------------------------------------------------------------------ */
function SceneParticles({ stateRef }: { stateRef: MutableRefObject<SceneState> }) {
  const pointsRef = useRef<THREE.Points>(null!)
  const count = useMemo(() => {
    const w = typeof window !== 'undefined' ? window.innerWidth : 1200
    return w < 768 ? 300 : 600
  }, [])

  const [positions] = useMemo(() => {
    const p = new Float32Array(count * 3)
    for (let i = 0; i < count; i++) {
      p[i * 3] = (Math.random() - 0.5) * 24
      p[i * 3 + 1] = (Math.random() - 0.5) * 24
      p[i * 3 + 2] = (Math.random() - 0.5) * 14
    }
    return [p]
  }, [count])

  const material = useMemo(() => new THREE.PointsMaterial({
    size: 0.045,
    transparent: true,
    opacity: 0.3,
    sizeAttenuation: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  }), [])

  useFrame((state) => {
    const dark = document.documentElement.classList.contains('dark')
    const t = state.clock.elapsedTime
    const s = stateRef.current
    const hue = s.hue
    const c = new THREE.Color().setHSL(hue / 360, 0.3, dark ? 0.55 : 0.35)
    material.color.copy(c)
    material.opacity = (dark ? 0.3 : 0.18) + s.morphFlash * 0.15
    material.size = 0.04 + s.morphFlash * 0.03

    const geo = pointsRef.current.geometry
    const pos = geo.attributes.position.array as Float32Array
    const speed = PARTICLE_SPEEDS[s.targetIdx]
    for (let i = 0; i < count; i++) {
      const idx = i * 3
      pos[idx + 1] += Math.sin(t + i * 0.01 + pos[idx] * 0.05) * 0.002 + speed
      if (pos[idx + 1] > 12) pos[idx + 1] = -12
      if (pos[idx + 1] < -12) pos[idx + 1] = 12
    }
    geo.attributes.position.needsUpdate = true
  })

  const geo = useMemo(() => {
    const g = new THREE.BufferGeometry()
    g.setAttribute('position', new THREE.BufferAttribute(positions, 3))
    return g
  }, [positions])

  return <points ref={pointsRef} geometry={geo} material={material} />
}

/* ------------------------------------------------------------------ */
/*  Rings                                                              */
/* ------------------------------------------------------------------ */
function Rings({ stateRef }: { stateRef: MutableRefObject<SceneState> }) {
  const groupRef = useRef<THREE.Group>(null!)
  const ringRefs = useRef<THREE.Mesh[]>([])
  const configs = useMemo(() => [
    { radius: 3.2, tube: 0.015, rot: [0.3, 0, 0] as const, pos: [0, 0.5, -2.5] as const },
    { radius: 2.4, tube: 0.012, rot: [1.2, 0.5, 0.3] as const, pos: [1.2, -0.8, 1] as const },
    { radius: 1.8, tube: 0.01, rot: [0.8, 1.2, 0] as const, pos: [-1.5, 1.2, 0.5] as const },
  ], [])

  useFrame((state) => {
    const t = state.clock.elapsedTime
    const s = stateRef.current
    groupRef.current.position.y = -s.scroll * 2.2
    const dark = document.documentElement.classList.contains('dark')

    ringRefs.current.forEach((mesh, i) => {
      if (!mesh) return
      mesh.rotation.x = configs[i].rot[0] + t * (0.04 + i * 0.02)
      mesh.rotation.y = configs[i].rot[1] + t * (0.06 - i * 0.015)
      const alpha = (dark ? 0.12 : 0.06) + 0.04 * Math.sin(t * 0.25 + i)
      ;(mesh.material as THREE.MeshBasicMaterial).opacity = alpha + s.morphFlash * 0.06
    })
  })

  return (
    <group ref={groupRef}>
      {configs.map((c, i) => (
        <mesh key={i} ref={(el) => { if (el) ringRefs.current[i] = el }} position={c.pos} rotation={c.rot}>
          <torusGeometry args={[c.radius, c.tube, 12, 64]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={0.08} depthWrite={false} />
        </mesh>
      ))}
    </group>
  )
}

/* ------------------------------------------------------------------ */
/*  SceneContent – main animation controller & state                   */
/* ------------------------------------------------------------------ */
function SceneContent() {
  const { scene } = useThree()
  const stateRef = useRef<SceneState>(createSceneState())
  const bgColorRef = useRef(new THREE.Color())

  // Scroll tracking
  useEffect(() => {
    const update = () => {
      const docHeight = document.documentElement.scrollHeight - window.innerHeight
      stateRef.current.scroll = docHeight > 0 ? window.scrollY / docHeight : 0
    }
    update()
    window.addEventListener('scroll', update, { passive: true })
    return () => window.removeEventListener('scroll', update)
  }, [])

  // Section detection with morph trigger
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        let bestId = ''
        let bestRatio = 0
        for (const entry of entries) {
          if (entry.intersectionRatio > bestRatio) {
            bestRatio = entry.intersectionRatio
            bestId = entry.target.id
          }
        }
        const newIdx = SECTION_IDS.indexOf(bestId)
        if (newIdx >= 0 && newIdx !== stateRef.current.targetIdx) {
          stateRef.current.prevTargetIdx = stateRef.current.targetIdx
          stateRef.current.targetIdx = newIdx
          stateRef.current.morphP = 0
          stateRef.current.morphFlash = 1
        }
      },
      { threshold: [0, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5] },
    )

    SECTION_IDS.forEach((id) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])

  // Theme observer
  useEffect(() => {
    const updateBg = () => {
      const dark = document.documentElement.classList.contains('dark')
      bgColorRef.current.set(dark ? '#07070d' : '#f8f9fa')
      scene.background = bgColorRef.current
    }
    updateBg()
    const obs = new MutationObserver(updateBg)
    obs.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] })
    return () => obs.disconnect()
  }, [scene])

  // Per-frame: hue lerp, morph progress, camera, flash decay
  useFrame((state, delta) => {
    const dt = Math.min(delta, 0.05)
    const s = stateRef.current

    // Hue interpolation
    const targetHue = SECTION_HUES[s.targetIdx]
    const diff = targetHue - s.hue
    if (Math.abs(diff) > 1) s.hue += diff * Math.min(1, dt * 2.5)
    else s.hue = targetHue

    // Morph progress
    if (s.morphP < 1) {
      s.morphP = Math.min(1, s.morphP + dt * 1.2)
      if (s.morphP >= 1) s.currentIdx = s.targetIdx
    }

    // Flash decay
    if (s.morphFlash > 0) {
      s.morphFlash = Math.max(0, s.morphFlash - dt * 3)
    }

    // Camera
    const scroll = s.scroll
    state.camera.position.y = -scroll * 2.8
    state.camera.position.x = Math.sin(scroll * Math.PI * 0.5) * 0.6
    state.camera.lookAt(0, -scroll * 1.4, 0)
  })

  return (
    <>
      <ambientLight intensity={0.25} />
      <hemisphereLight args={['#ffffff', '#000000', 0.4]} />
      <directionalLight position={[5, 8, 6]} intensity={0.6} color="#f0e6ff" />
      <directionalLight position={[-4, -2, 5]} intensity={0.3} color="#e0f0ff" />
      <pointLight position={[0, 6, -4]} intensity={0.4} color="#fce7f3" />

      {/* Far blobs – each with unique morph wave direction */}
      <Blob position={[-3.5, 1, -5]} scale={2.2} speed={0.6} stateRef={stateRef} shapeIdx={0} morphDir={1} />
      <Blob position={[3.2, -0.5, -6]} scale={2.8} speed={0.4} stateRef={stateRef} shapeIdx={1} morphDir={-1} />
      <Blob position={[0, 2, -8]} scale={3.5} speed={0.3} stateRef={stateRef} shapeIdx={2} morphDir={0.5} />

      {/* Glass spheres */}
      <GlassSphere position={[-1.8, 1.5, -1]} scale={1} stateRef={stateRef} />
      <GlassSphere position={[2.2, -0.8, 0.5]} scale={0.75} stateRef={stateRef} />
      <GlassSphere position={[-0.5, -1.5, -2]} scale={0.55} stateRef={stateRef} />

      {/* Ribbons */}
      <Ribbon stateRef={stateRef} offset={0} />
      <Ribbon stateRef={stateRef} offset={Math.PI} />

      {/* Rings */}
      <Rings stateRef={stateRef} />

      {/* Particles */}
      <SceneParticles stateRef={stateRef} />
    </>
  )
}

/* ------------------------------------------------------------------ */
/*  ThreeDScene – main export                                          */
/* ------------------------------------------------------------------ */
export function ThreeDScene() {
  return (
    <Canvas
      gl={{
        antialias: true,
        toneMapping: THREE.ACESFilmicToneMapping,
        toneMappingExposure: 1.0,
        outputColorSpace: THREE.SRGBColorSpace,
      }}
      camera={{ position: [0, 0, 12], fov: 55, near: 0.1, far: 50 }}
      style={{
        position: 'fixed',
        inset: 0,
        width: '100%',
        height: '100%',
        pointerEvents: 'none',
        zIndex: 0,
      }}
    >
      <SceneContent />
    </Canvas>
  )
}
