import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { useLanguage, languageNames } from '@/context/LanguageContext'
import type { Language } from '@/types'
import { Languages } from 'lucide-react'

const languages: Language[] = ['en', 'es', 'fr', 'de', 'ja', 'zh']

const flagEmoji: Record<Language, string> = {
  en: '🇬🇧',
  es: '🇪🇸',
  fr: '🇫🇷',
  de: '🇩🇪',
  ja: '🇯🇵',
  zh: '🇨🇳',
}

export function LanguageSwitcher() {
  const [isOpen, setIsOpen] = useState(false)
  const { language, setLanguage } = useLanguage()

  return (
    <>
      <motion.button
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        whileHover={{ scale: 1.05 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-36 z-40 w-10 h-10 rounded-xl bg-foreground/5 flex items-center justify-center text-foreground/60 hover:text-foreground hover:bg-foreground/10 transition-all backdrop-blur-lg"
        aria-label="Switch language"
      >
        <Languages size={18} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="fixed bottom-20 right-36 z-40 glass-card rounded-2xl p-2 shadow-2xl w-44"
          >
            <div className="space-y-0.5">
              {languages.map((lang) => {
                const isActive = language === lang
                const names = languageNames[lang]
                return (
                  <button
                    key={lang}
                    onClick={() => { setLanguage(lang); setIsOpen(false) }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                      isActive
                        ? 'bg-nova-500/10 text-nova-600 dark:text-nova-400'
                        : 'text-foreground/60 hover:text-foreground hover:bg-foreground/5'
                    }`}
                  >
                    <span className="text-base leading-none">{flagEmoji[lang]}</span>
                    <span className="flex-1 text-left">{names.native}</span>
                    {isActive && (
                      <motion.span
                        layoutId="lang-active"
                        className="w-1.5 h-1.5 rounded-full bg-nova-500"
                      />
                    )}
                  </button>
                )
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
