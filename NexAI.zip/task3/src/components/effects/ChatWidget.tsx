import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MessageCircle } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

export function ChatWidget() {
  const { t } = useLanguage()

  const initialMessages = [
    { id: '1', text: t('chat.greeting'), sender: 'bot' as const },
  ]

  const responses: Record<string, string> = {
    pricing: t('chat.responsePricing'),
    features: t('chat.responseFeatures'),
    demo: t('chat.responseDemo'),
    trial: t('chat.responseTrial'),
    default: t('chat.responseDefault'),
  }

  const [isOpen, setIsOpen] = useState(false)
  const [chatMessages, setChatMessages] = useState(initialMessages)
  const [input, setInput] = useState('')
  const [isTyping, setIsTyping] = useState(false)
  const chatEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [chatMessages, isTyping])

  const handleSend = () => {
    if (!input.trim()) return
    const userMsg = { id: Date.now().toString(), text: input, sender: 'user' as const }
    setChatMessages(prev => [...prev, userMsg])
    setInput('')
    setIsTyping(true)

    setTimeout(() => {
      const lower = input.toLowerCase()
      let reply = responses.default
      if (lower.includes('price') || lower.includes('cost') || lower.includes('plan')) reply = responses.pricing
      else if (lower.includes('feature') || lower.includes('what')) reply = responses.features
      else if (lower.includes('demo') || lower.includes('show')) reply = responses.demo
      else if (lower.includes('trial') || lower.includes('free')) reply = responses.trial

      setChatMessages(prev => [...prev, { id: (Date.now() + 1).toString(), text: reply, sender: 'bot' as const }])
      setIsTyping(false)
    }, 1500)
  }

  return (
    <>
      <motion.button
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 left-6 z-40 w-14 h-14 rounded-2xl bg-gradient-to-br from-nova-500 to-purple-600 text-white flex items-center justify-center shadow-xl shadow-nova-500/30 hover:shadow-nova-500/50 transition-all"
        aria-label={t('nav.openChat')}
      >
        <MessageCircle size={24} />
      </motion.button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="fixed bottom-24 left-6 z-40 w-80 sm:w-96 glass-card rounded-2xl shadow-2xl overflow-hidden"
          >
            <div className="p-4 border-b border-black/5 dark:border-white/10 dark:border-black/5 dark:border-white/10">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">AI</div>
                <div>
                  <div className="text-sm font-semibold">{t('chat.title')}</div>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                    <span className="text-xs text-foreground/40">{t('chat.online')}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="h-80 overflow-y-auto p-4 space-y-3 scrollbar-hide">
              {chatMessages.map(msg => (
                <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[80%] p-3 rounded-2xl text-sm ${msg.sender === 'user' ? 'bg-nova-600 text-white rounded-tr-sm' : 'glass rounded-tl-sm'}`}>
                    {msg.text}
                  </div>
                </div>
              ))}
              {isTyping && (
                <div className="flex justify-start">
                  <div className="glass p-3 rounded-2xl rounded-tl-sm">
                    <div className="flex gap-1">
                      <span className="w-2 h-2 rounded-full bg-nova-500 animate-bounce" />
                      <span className="w-2 h-2 rounded-full bg-nova-500 animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <span className="w-2 h-2 rounded-full bg-nova-500 animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="p-4 border-t border-black/5 dark:border-white/10 dark:border-black/5 dark:border-white/10">
              <div className="flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder={t('chat.placeholder')}
                  className="flex-1 h-10 px-4 rounded-xl glass text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30"
                />
                <button onClick={handleSend} className="w-10 h-10 rounded-xl bg-nova-600 text-white flex items-center justify-center hover:bg-nova-700 transition-all" aria-label={t('nav.send')}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z" /></svg>
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}