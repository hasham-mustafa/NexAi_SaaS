import { motion } from 'framer-motion'

export function AnimatedBlob({ className }: { className?: string }) {
  return (
    <div className={`absolute pointer-events-none ${className}`} aria-hidden="true">
      <motion.div
        className="w-full h-full rounded-full bg-gradient-to-r from-nova-500/20 via-purple-500/15 to-pink-500/10 blur-3xl"
        animate={{
          scale: [1, 1.2, 1],
          rotate: [0, 45, 0],
          x: [0, 30, 0],
          y: [0, -30, 0],
        }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  )
}

export function FloatingElement({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  return (
    <motion.div
      className={className}
      animate={{
        y: [0, -15, 0],
      }}
      transition={{
        duration: 4,
        repeat: Infinity,
        ease: 'easeInOut',
        delay,
      }}
    >
      {children}
    </motion.div>
  )
}

export function GlowEffect({ className }: { className?: string }) {
  return (
    <div className={`absolute -z-10 ${className}`} aria-hidden="true">
      <motion.div
        className="w-full h-full rounded-full bg-gradient-radial from-nova-500/30 via-purple-500/20 to-transparent"
        animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.6, 0.3] }}
        transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
      />
    </div>
  )
}