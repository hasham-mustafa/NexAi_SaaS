import { useEffect } from 'react'

export function CustomCursor() {
  useEffect(() => {
    if ('ontouchstart' in window) return

    const cursor = document.createElement('div')
    cursor.className = 'fixed top-0 left-0 pointer-events-none z-[9999] w-6 h-6 rounded-full bg-nova-400/30 dark:bg-nova-500/30 -translate-x-1/2 -translate-y-1/2 transition-all duration-200 ease-out'
    cursor.style.display = 'none'
    document.body.appendChild(cursor)

    const trail = document.createElement('div')
    trail.className = 'fixed top-0 left-0 pointer-events-none z-[9998] w-2 h-2 rounded-full bg-nova-500/40 -translate-x-1/2 -translate-y-1/2 transition-all duration-500 ease-out'
    trail.style.display = 'none'
    document.body.appendChild(trail)

    document.body.style.cursor = 'none'

    const mouse = { x: 0, y: 0 }
    const trailPos = { x: 0, y: 0 }
    let rafId: number

    const onMove = (e: MouseEvent) => {
      mouse.x = e.clientX
      mouse.y = e.clientY
      cursor.style.display = 'block'
      trail.style.display = 'block'
      cursor.style.transform = `translate(${mouse.x}px, ${mouse.y}px)`
    }

    const animate = () => {
      trailPos.x += (mouse.x - trailPos.x) * 0.15
      trailPos.y += (mouse.y - trailPos.y) * 0.15
      trail.style.transform = `translate(${trailPos.x}px, ${trailPos.y}px)`
      rafId = requestAnimationFrame(animate)
    }

    const enlarge = () => {
      cursor.style.width = '40px'
      cursor.style.height = '40px'
      cursor.style.border = '2px solid rgba(99, 102, 241, 0.5)'
      cursor.style.background = 'rgba(99, 102, 241, 0.1)'
    }
    const shrink = () => {
      cursor.style.width = '24px'
      cursor.style.height = '24px'
      cursor.style.border = 'none'
      cursor.style.background = ''
    }

    window.addEventListener('mousemove', onMove)
    document.addEventListener('mouseleave', () => { cursor.style.display = 'none'; trail.style.display = 'none' })
    document.querySelectorAll('a, button, [role="button"], input, textarea, select').forEach((el) => {
      el.addEventListener('mouseenter', enlarge)
      el.addEventListener('mouseleave', shrink)
    })
    rafId = requestAnimationFrame(animate)

    return () => {
      cursor.remove()
      trail.remove()
      document.body.style.cursor = ''
      cancelAnimationFrame(rafId)
      window.removeEventListener('mousemove', onMove)
    }
  }, [])

  return null
}