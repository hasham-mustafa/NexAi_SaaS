import { motion } from 'framer-motion'

const dockItems = [
  { icon: '◇', label: 'Home', href: '#' },
  { icon: '⚡', label: 'Features', href: '#features' },
  { icon: '◆', label: 'Pricing', href: '#pricing' },
  { icon: '✦', label: 'Blog', href: '#blog' },
  { icon: '✉', label: 'Contact', href: '#contact' },
]

export function FloatingDock() {
  return (
    <motion.div
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
      className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40 hidden md:flex"
    >
      <div className="glass rounded-2xl px-3 py-2 flex items-center gap-1 shadow-xl">
        {dockItems.map((item) => (
          <a
            key={item.label}
            href={item.href}
            className="group relative px-3 py-2 rounded-xl hover:bg-foreground/5 transition-all duration-200"
          >
            <span className="text-lg">{item.icon}</span>
            <span className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 rounded-lg glass text-xs whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              {item.label}
            </span>
          </a>
        ))}
      </div>
    </motion.div>
  )
}