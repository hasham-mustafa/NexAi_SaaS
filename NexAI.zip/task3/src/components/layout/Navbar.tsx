import { useState, useEffect, useRef, useCallback } from 'react'
import { Menu, X, Moon, Sun } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { useTheme } from '@/context/ThemeContext'
import { useLanguage } from '@/context/LanguageContext'

const navItems = [
  { id: 'home', key: 'nav.home', href: '#home' },
  { id: 'features', key: 'nav.features', href: '#features' },
  { id: 'showcase', key: 'nav.showcase', href: '#showcase' },
  { id: 'pricing', key: 'nav.pricing', href: '#pricing' },
  { id: 'comparison', key: 'nav.comparison', href: '#comparison' },
  { id: 'testimonials', key: 'nav.testimonials', href: '#testimonials' },
  { id: 'faq', key: 'nav.faq', href: '#faq' },
  { id: 'blog', key: 'nav.blog', href: '#blog' },
  { id: 'contact', key: 'nav.contact', href: '#contact' },
]

export function Navbar() {
  const { theme, toggleTheme } = useTheme()
  const { t } = useLanguage()
  const [isOpen, setIsOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [activeId, setActiveId] = useState('home')
  const [hoveredId, setHoveredId] = useState<string | null>(null)
  const [indicatorStyle, setIndicatorStyle] = useState({ left: 0, width: 0, opacity: 0 })
  const navRef = useRef<HTMLDivElement>(null)
  const linkRefs = useRef<Map<string, HTMLAnchorElement>>(new Map())

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  // Active section tracking
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        let bestId = ''
        let bestRatio = 0
        for (const entry of entries) {
          if (entry.intersectionRatio > bestRatio) {
            bestRatio = entry.intersectionRatio
            bestId = entry.target.id
          }
        }
        if (bestId && navItems.some(n => n.id === bestId)) {
          setActiveId(bestId)
        }
      },
      { threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5] }
    )

    navItems.forEach(({ id }) => {
      const el = document.getElementById(id)
      if (el) observer.observe(el)
    })
    return () => observer.disconnect()
  }, [])

  // Animated hover indicator
  const updateIndicator = useCallback((id: string | null) => {
    if (!id) {
      setIndicatorStyle(prev => ({ ...prev, opacity: 0 }))
      return
    }
    const el = linkRefs.current.get(id)
    if (el && navRef.current) {
      const navRect = navRef.current.getBoundingClientRect()
      const rect = el.getBoundingClientRect()
      setIndicatorStyle({
        left: rect.left - navRect.left,
        width: rect.width,
        opacity: 1,
      })
    }
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-700 ${
        scrolled
          ? 'glass border-b border-black/5 dark:border-white/10 shadow-lg shadow-black/5 backdrop-blur-2xl'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 md:h-16">
          {/* Logo */}
          <motion.a
            href="#"
            className="flex items-center gap-2.5 group"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <motion.div
              className="w-8 h-8 rounded-lg bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm shadow-md shadow-nova-500/20"
              whileHover={{ rotate: [0, -10, 10, -5, 0], scale: 1.1 }}
              transition={{ duration: 0.4 }}
            >
              N
            </motion.div>
            <span className="text-lg font-bold tracking-tight">NexAI</span>
          </motion.a>

          {/* Desktop Nav */}
          <div ref={navRef} className="hidden md:flex items-center relative">
            <div className="flex items-center gap-1 relative px-1">
              {/* Hover highlight indicator */}
              <motion.div
                className="absolute top-1 bottom-1 rounded-lg bg-nova-500/10 dark:bg-nova-500/15 pointer-events-none"
                animate={{
                  left: indicatorStyle.left,
                  width: indicatorStyle.width,
                  opacity: indicatorStyle.opacity,
                }}
                transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              />

              {/* Active section indicator */}
              {navItems.map((item) => {
                const isActive = activeId === item.id && hoveredId === null
                return (
                  <a
                    key={item.id}
                    ref={(el) => { if (el) linkRefs.current.set(item.id, el) }}
                    href={item.href}
                    onMouseEnter={() => {
                      setHoveredId(item.id)
                      updateIndicator(item.id)
                    }}
                    onMouseLeave={() => {
                      setHoveredId(null)
                      updateIndicator(null)
                    }}
                    className="relative px-4 py-2 text-sm font-medium rounded-lg transition-colors duration-300"
                  >
                    <span
                      className={`relative z-10 transition-colors duration-300 ${
                        isActive
                          ? 'text-nova-600 dark:text-nova-400'
                          : 'text-foreground/50 hover:text-foreground/80'
                      }`}
                    >
                      {t(item.key as 'nav.home')}
                    </span>
                    {isActive && (
                      <motion.div
                        layoutId="nav-active"
                        className="absolute inset-0 rounded-lg bg-nova-500/8 dark:bg-nova-500/10"
                        transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                      />
                    )}
                  </a>
                )
              })}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {/* Theme toggle */}
            <motion.button
              onClick={toggleTheme}
              whileHover={{ scale: 1.08, rotate: 15 }}
              whileTap={{ scale: 0.9, rotate: -15 }}
              className="p-2.5 rounded-xl text-foreground/50 hover:text-foreground hover:bg-foreground/5 transition-colors duration-300"
              aria-label={theme === 'dark' ? t('nav.toggleLight') : t('nav.toggleDark')}
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={theme}
                  initial={{ y: -8, opacity: 0, rotate: -45 }}
                  animate={{ y: 0, opacity: 1, rotate: 0 }}
                  exit={{ y: 8, opacity: 0, rotate: 45 }}
                  transition={{ duration: 0.25 }}
                >
                  {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
                </motion.div>
              </AnimatePresence>
            </motion.button>

            {/* Get Started */}
            <motion.a
              href="#contact"
              className="hidden md:inline-flex h-10 px-5 items-center justify-center rounded-xl bg-gradient-to-b from-nova-500 to-nova-600 text-white text-sm font-medium shadow-lg shadow-nova-500/20 overflow-hidden relative group"
              whileHover={{ scale: 1.03, y: -1 }}
              whileTap={{ scale: 0.97 }}
            >
              <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-500 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg]" />
              <span className="relative z-10">{t('nav.getStarted')}</span>
              <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300 rounded-xl" />
            </motion.a>

            {/* Mobile menu button */}
            <motion.button
              onClick={() => setIsOpen(!isOpen)}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.9 }}
              className="md:hidden p-2.5 rounded-xl text-foreground/50 hover:text-foreground hover:bg-foreground/5 transition-colors duration-300"
              aria-label={t('nav.toggleMenu')}
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={isOpen ? 'close' : 'menu'}
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                >
                  {isOpen ? <X size={20} /> : <Menu size={20} />}
                </motion.div>
              </AnimatePresence>
            </motion.button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
            className="glass border-b border-black/5 dark:border-white/10 md:hidden overflow-hidden"
          >
            <div className="p-4 space-y-1">
              {navItems.map((item, i) => (
                <motion.a
                  key={item.id}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.04, duration: 0.3 }}
                  className="block px-4 py-3 text-sm font-medium text-foreground/60 hover:text-foreground rounded-xl hover:bg-foreground/5 transition-all relative overflow-hidden group"
                  whileHover={{ x: 4 }}
                >
                  <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-500 bg-gradient-to-r from-transparent via-nova-500/5 to-transparent" />
                    <span className="relative z-10">{t(item.key as 'nav.home')}</span>
                </motion.a>
              ))}
              <motion.a
                href="#contact"
                onClick={() => setIsOpen(false)}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: navItems.length * 0.04 + 0.1 }}
                className="block px-4 py-3 text-sm font-medium text-center rounded-xl bg-gradient-to-b from-nova-500 to-nova-600 text-white mt-3 shadow-lg shadow-nova-500/20 relative overflow-hidden"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                {t('nav.getStarted')}
              </motion.a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  )
}
