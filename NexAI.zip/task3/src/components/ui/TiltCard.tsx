import { type ReactNode, useRef } from 'react'
import { motion, useMotionValue, useSpring } from 'framer-motion'

interface TiltCardProps {
  children: ReactNode
  className?: string
  intensity?: number
}

export function TiltCard({ children, className, intensity = 12 }: TiltCardProps) {
  const ref = useRef<HTMLDivElement>(null)
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const shineX = useMotionValue(50)
  const shineY = useMotionValue(50)

  const springX = useSpring(x, { stiffness: 250, damping: 25 })
  const springY = useSpring(y, { stiffness: 250, damping: 25 })

  const handleMouseMove = (e: React.MouseEvent) => {
    const rect = ref.current?.getBoundingClientRect()
    if (!rect) return
    const cx = rect.left + rect.width / 2
    const cy = rect.top + rect.height / 2
    x.set((e.clientX - cx) / intensity)
    y.set((e.clientY - cy) / intensity)
    shineX.set(((e.clientX - rect.left) / rect.width) * 100)
    shineY.set(((e.clientY - rect.top) / rect.height) * 100)
    ref.current?.style.setProperty('--mx', `${shineX.get()}%`)
    ref.current?.style.setProperty('--my', `${shineY.get()}%`)
  }

  const handleMouseLeave = () => {
    x.set(0)
    y.set(0)
    shineX.set(50)
    shineY.set(50)
    ref.current?.style.setProperty('--mx', '50%')
    ref.current?.style.setProperty('--my', '50%')
  }

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      style={{ rotateX: springY, rotateY: springX, transformPerspective: 1200 }}
      className={`relative ${className}`}
    >
      {children}
      <div
        className="absolute inset-0 rounded-2xl pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-10"
        style={{
          background: `radial-gradient(circle at ${shineX}% ${shineY}%, rgba(255,255,255,0.12), transparent 60%)`,
        }}
      />
    </motion.div>
  )
}
