import { type ReactNode, useRef, type MouseEvent } from 'react'
import { cn } from '@/utils/cn'

interface GlassCardProps {
  children: ReactNode
  className?: string
  as?: 'div' | 'section' | 'article'
  hover?: boolean
  glow?: boolean
  spotlight?: boolean
}

export function GlassCard({ children, className, as: Tag = 'div', hover, glow, spotlight: withSpotlight }: GlassCardProps) {
  const cardRef = useRef<HTMLDivElement>(null)

  const handleMouseMove = (e: MouseEvent) => {
    if (!withSpotlight || !cardRef.current) return
    const rect = cardRef.current.getBoundingClientRect()
    cardRef.current.style.setProperty('--mx', `${((e.clientX - rect.left) / rect.width) * 100}%`)
    cardRef.current.style.setProperty('--my', `${((e.clientY - rect.top) / rect.height) * 100}%`)
  }

  return (
    <Tag
      ref={cardRef}
      onMouseMove={handleMouseMove}
      className={cn(
        'glass-card rounded-2xl p-6',
        hover && 'premium-card-hover',
        glow && 'glass-glow',
        withSpotlight && 'spotlight premium-card-glow',
        className
      )}
    >
      {children}
    </Tag>
  )
}
