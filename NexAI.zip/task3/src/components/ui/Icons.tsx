import { type ElementType, type ReactNode } from 'react'
import { cn } from '@/utils/cn'

interface IconProps {
  icon: ElementType
  className?: string
  size?: number
  animated?: boolean
}

export function IconBox({ icon: Icon, className, size = 24, animated }: IconProps) {
  return (
    <Icon
      className={cn(
        animated && 'group-hover:scale-110 group-hover:rotate-3 transition-all duration-500',
        className
      )}
      size={size}
    />
  )
}

export function IconWrapper({
  children,
  className,
  gradient,
  glow,
}: {
  children: ReactNode
  className?: string
  gradient?: string
  glow?: boolean
}) {
  return (
    <div
      className={cn(
        'inline-flex items-center justify-center w-12 h-12 rounded-xl bg-gradient-to-br text-white relative overflow-hidden',
        gradient || 'from-nova-500 to-purple-600',
        glow && 'shadow-lg shadow-nova-500/20',
        className
      )}
    >
      {/* Shine */}
      <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg]" />
      <span className="relative z-10">{children}</span>
    </div>
  )
}

export function PremiumIconWrapper({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <div
      className={cn(
        'inline-flex items-center justify-center w-12 h-12 rounded-xl relative overflow-hidden',
        'bg-gradient-to-br from-nova-500/10 via-purple-500/10 to-pink-500/10',
        'border border-nova-500/10 dark:border-nova-500/20',
        'shadow-sm',
        'group-hover:scale-110 group-hover:shadow-lg group-hover:shadow-nova-500/10 transition-all duration-500',
        className
      )}
    >
      <span className="absolute inset-0 bg-gradient-to-br from-nova-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
      <span className="relative z-10 text-nova-600 dark:text-nova-400">{children}</span>
    </div>
  )
}
