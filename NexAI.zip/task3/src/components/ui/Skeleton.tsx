import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Check } from 'lucide-react'
import { cn } from '@/utils/cn'

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn('animate-pulse rounded-xl bg-foreground/5', className)} />
}

export function SkeletonCard() {
  return (
    <div className="rounded-2xl p-6 space-y-4 border border-foreground/10 bg-foreground/[0.02]">
      <Skeleton className="h-12 w-12 rounded-xl" />
      <Skeleton className="h-5 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
    </div>
  )
}

export function LoadingScreen() {
  const [show, setShow] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => setShow(false), 2000)
    return () => clearTimeout(timer)
  }, [])

  if (!show) return null

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-white dark:bg-neutral-950">
      <div className="flex flex-col items-center gap-4">
        <motion.div
          className="relative w-16 h-16"
          animate={{ rotate: 360 }}
          transition={{ duration: 1.5, repeat: Infinity, ease: 'linear' }}
        >
          <div className="absolute inset-0 rounded-full bg-gradient-to-r from-nova-500 to-purple-600" />
          <div className="absolute inset-1 rounded-full bg-white dark:bg-neutral-950 flex items-center justify-center">
            <span className="text-lg font-bold gradient-text">N</span>
          </div>
        </motion.div>
        <motion.p
          className="text-sm text-neutral-500 dark:text-neutral-400"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          Loading...
        </motion.p>
      </div>
    </div>
  )
}

export function Checkmark({ className }: { className?: string }) {
  return (
    <span className={cn('inline-flex items-center justify-center w-5 h-5 rounded-full bg-nova-500/20 text-nova-500', className)}>
      <Check size={12} strokeWidth={3} />
    </span>
  )
}