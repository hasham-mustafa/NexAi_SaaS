import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'outline'
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  children?: ReactNode
}

const base =
  'relative inline-flex items-center justify-center font-medium rounded-xl transition-all duration-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-nova-500 focus-visible:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none group overflow-hidden'

const variants = {
  primary:
    'bg-gradient-to-b from-nova-500 to-nova-600 text-white shadow-lg shadow-nova-500/20 hover:shadow-xl hover:shadow-nova-500/30 hover:-translate-y-0.5 active:translate-y-0',
  secondary:
    'glass-deep text-foreground hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0',
  ghost:
    'bg-transparent text-foreground hover:bg-black/5 dark:hover:bg-white/5',
  outline:
    'bg-transparent text-foreground border border-foreground/10 hover:border-foreground/20 hover:bg-black/5 dark:hover:bg-white/5',
}

const sizes = {
  sm: 'h-9 px-4 text-sm gap-2',
  md: 'h-11 px-6 text-sm gap-2',
  lg: 'h-12 px-8 text-base gap-2.5',
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', loading, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={`${base} ${variants[variant]} ${sizes[size]} ${className || ''}`}
        disabled={props.disabled || loading}
        {...props}
      >
        {/* Shine overlay */}
        <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/15 to-transparent skew-x-[-20deg]" />

        {variant === 'primary' && (
          <span className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none -z-20 blur-xl bg-[conic-gradient(from_0deg,#6366f1,#a855f7,#ec4899,#6366f1)] animate-[spin_3s_linear_infinite]" />
        )}

        {/* Animated border glow for primary */}
        {variant === 'primary' && (
          <span className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none border border-white/20" />
        )}

        {loading && (
          <svg className="animate-spin h-4 w-4 relative z-10" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
          </svg>
        )}
        <span className="relative z-10 inline-flex items-center gap-2">{children}</span>

        {/* Inner highlight */}
        <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 rounded-xl" />
      </button>
    )
  }
)

Button.displayName = 'Button'
