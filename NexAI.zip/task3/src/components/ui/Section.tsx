import { type ReactNode } from 'react'
import { motion } from 'framer-motion'

interface SectionProps {
  children: ReactNode
  className?: string
  id?: string
  dark?: boolean
}

export function Section({ children, className, id, dark }: SectionProps) {
  return (
    <motion.section
      id={id}
      initial={{ opacity: 0 }}
      whileInView={{ opacity: 1 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
      className={`relative py-24 md:py-32 ${dark ? 'bg-foreground/[0.02]' : ''} ${className || ''}`}
    >
      {children}
    </motion.section>
  )
}

export function SectionHeader({
  title,
  subtitle,
  className,
  badge,
}: {
  title: string
  subtitle?: string
  className?: string
  badge?: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
      className={`text-center max-w-3xl mx-auto mb-16 md:mb-20 ${className || ''}`}
    >
      {badge && (
        <motion.div
          initial={{ opacity: 0, y: 10, scale: 0.95 }}
          whileInView={{ opacity: 1, y: 0, scale: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          className="premium-badge mb-6"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-nova-500 animate-pulse" />
          {badge}
        </motion.div>
      )}
      <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-balance">
        <span className="gradient-text">{title}</span>
      </h2>
      {subtitle && (
        <p className="mt-6 text-lg md:text-xl text-foreground/60 leading-relaxed max-w-2xl mx-auto">
          {subtitle}
        </p>
      )}
    </motion.div>
  )
}
