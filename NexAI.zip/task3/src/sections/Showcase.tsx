import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { SectionHeader } from '@/components/ui/Section'
import { Play, ArrowRight } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

const previews: Record<string, { stats: [string, string, string][]; bars: { label: string; pct: number }[] }> = {
  dashboard: {
    stats: [
      ['Revenue', '$128.4k', '+23.5%'],
      ['Users', '52.1k', '+12.3%'],
      ['Conversion', '4.8%', '+2.1%'],
    ],
    bars: [
      { label: 'AI Automation', pct: 92 },
      { label: 'Analytics Engine', pct: 78 },
      { label: 'Customer Insights', pct: 65 },
    ],
  },
  automation: {
    stats: [
      ['Workflows', '284', '+18%'],
      ['Run Time', '1.2s', '-34%'],
      ['Success', '99.7%', '+0.5%'],
    ],
    bars: [
      { label: 'Active', pct: 95 },
      { label: 'Completed', pct: 82 },
      { label: 'Scheduled', pct: 60 },
    ],
  },
  analytics: {
    stats: [
      ['Queries', '14.2k', '+8.7%'],
      ['Models', '12', '+3'],
      ['Accuracy', '96.8%', '+2.2%'],
    ],
    bars: [
      { label: 'Predictions', pct: 88 },
      { label: 'Training', pct: 72 },
      { label: 'Deployed', pct: 55 },
    ],
  },
  team: {
    stats: [
      ['Members', '34', '+5'],
      ['Projects', '18', '+3'],
      ['Activity', '92%', '+4%'],
    ],
    bars: [
      { label: 'Active', pct: 91 },
      { label: 'In Review', pct: 63 },
      { label: 'Completed', pct: 77 },
    ],
  },
  security: {
    stats: [
      ['Threats', '0', 'Blocked'],
      ['Audits', '24/7', 'Active'],
      ['Uptime', '99.99%', 'SLA'],
    ],
    bars: [
      { label: 'Encryption', pct: 100 },
      { label: 'Compliance', pct: 96 },
      { label: 'Monitoring', pct: 88 },
    ],
  },
}

export default function Showcase() {
  const { t } = useLanguage()
  const [active, setActive] = useState('dashboard')
  const data = previews[active]
  const tabs = [
    { id: 'dashboard', label: t('showcase.tabDashboard'), desc: 'Real-time analytics and KPIs at a glance.', image: null },
    { id: 'automation', label: t('showcase.tabAutomation'), desc: 'Build no-code AI workflows in minutes.', image: null },
    { id: 'analytics', label: t('showcase.tabAnalytics'), desc: 'Deep insights powered by machine learning.', image: null },
    { id: 'team', label: t('showcase.tabTeam'), desc: 'Collaborate across your organization.', image: null },
    { id: 'security', label: t('showcase.tabSecurity'), desc: 'Enterprise-grade security and compliance.', image: null },
  ]
  return (
    <section id="showcase" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-0 left-0 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge={t('section.showcase.badge')}
          title={t('section.showcase.title')}
          subtitle={t('section.showcase.subtitle')}
        />

        {/* Tabs */}
        <div className="flex justify-center mb-12">
          <div className="inline-flex p-1.5 rounded-2xl glass-deep gap-1">
            {tabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => setActive(tab.id)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                  active === tab.id
                    ? 'bg-gradient-to-r from-nova-500 to-purple-600 text-white shadow-lg shadow-nova-500/30'
                    : 'text-foreground/60 hover:text-foreground'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Preview */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="glass-card premium-card-border rounded-3xl p-2 max-w-4xl mx-auto spotlight premium-card-glow"
          >
            <div className="rounded-2xl bg-gradient-to-br from-nova-500/5 via-purple-500/5 to-pink-500/5 overflow-hidden">
              <div className="p-8 md:p-10 space-y-8">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-rose-500 shadow-lg shadow-rose-500/40" />
                    <span className="w-3 h-3 rounded-full bg-amber-500 shadow-lg shadow-amber-500/40" />
                    <span className="w-3 h-3 rounded-full bg-emerald-500 shadow-lg shadow-emerald-500/40" />
                  </div>
                  <span className="text-xs text-foreground/40 font-mono">nexai.app/{active}</span>
                </div>

                <p className="text-base text-foreground/60">{tabs.find(t => t.id === active)?.desc}</p>

                <div className="grid grid-cols-3 gap-5">
                  {data.stats.map(([label, value, change]) => (
                    <div key={label} className="glass-deep premium-card rounded-2xl p-5 text-center">
                      <div className="text-xs text-foreground/40 mb-1.5 uppercase tracking-wider font-medium">{label}</div>
                      <div className="text-xl md:text-2xl font-bold gradient-text">{value}</div>
                      <div className="text-xs text-emerald-500 mt-1.5 font-medium">{change}</div>
                    </div>
                  ))}
                </div>

                <div className="glass-deep premium-card rounded-2xl p-6">
                  <div className="flex items-center justify-between mb-5">
                    <span className="text-xs text-foreground/40 uppercase tracking-wider font-medium">Metrics Overview</span>
                    <span className="text-xs text-nova-500 font-medium bg-nova-500/10 px-2.5 py-1 rounded-full">Live</span>
                  </div>
                  <div className="space-y-4">
                    {data.bars.map((bar, i) => (
                      <div key={bar.label}>
                        <div className="flex justify-between text-sm mb-1.5">
                          <span className="text-foreground/70 font-medium">{bar.label}</span>
                          <span className="text-foreground/50 font-mono text-xs">{bar.pct}%</span>
                        </div>
                        <div className="h-2.5 rounded-full bg-foreground/5 relative overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${bar.pct}%` }}
                            transition={{ duration: 0.8, delay: 0.2 + i * 0.1 }}
                            className="h-full rounded-full bg-gradient-to-r from-nova-500 to-purple-500 shadow-lg shadow-nova-500/30"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Video placeholder */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center"
        >
          <button
            className="inline-flex items-center gap-4 px-7 py-3.5 rounded-2xl glass-deep premium-card hover:bg-white/80 dark:hover:bg-white/10 transition-all group shadow-lg shadow-nova-500/10"
          >
            <div className="w-11 h-11 rounded-full bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center group-hover:scale-110 transition-transform shadow-lg shadow-nova-500/30">
              <Play size={18} className="text-white ml-0.5" />
            </div>
            <div className="text-left">
              <div className="text-sm font-medium">{t('showcase.watchDemo')}</div>
              <div className="text-xs text-foreground/40">{t('showcase.duration')}</div>
            </div>
            <ArrowRight size={16} className="text-foreground/40 group-hover:translate-x-1 transition-transform" />
          </button>
        </motion.div>
      </div>
    </section>
  )
}