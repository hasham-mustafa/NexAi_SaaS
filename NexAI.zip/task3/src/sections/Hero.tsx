import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowDown, Play, Zap } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

const words = ['Workflows', 'Analytics', 'Decisions', 'Growth', 'Automation']

function AnimatedCounter({ value, suffix }: { value: number; suffix: string }) {
  const [count, setCount] = useState(0)
  const [started, setStarted] = useState(false)

  useEffect(() => {
    if (started) return
    setStarted(true)
    const t0 = performance.now()
    const tick = (now: number) => {
      const p = Math.min((now - t0) / 2000, 1)
      setCount(Math.floor((1 - Math.pow(1 - p, 3)) * value))
      if (p < 1) requestAnimationFrame(tick)
    }
    requestAnimationFrame(tick)
  }, [value, started])

  return <div className="text-2xl md:text-3xl font-bold tracking-tight">{count.toLocaleString()}{suffix}</div>
}

export default function Hero() {
  const { t } = useLanguage()

  const stats = [
    { value: 50000, suffix: '+', label: t('hero.statActiveUsers') },
    { value: 1000, suffix: '+', label: t('hero.statEnterpriseClients') },
    { value: 99.9, suffix: '%', label: t('hero.statUptime') },
    { value: 150, suffix: 'M+', label: t('hero.statApiCalls') },
  ]

  const companies = [
    { name: 'TechFlow', logo: 'T' },
    { name: 'ApexLabs', logo: 'A' },
    { name: 'Cipher', logo: 'C' },
    { name: 'Venture', logo: 'V' },
    { name: 'Pulse', logo: 'P' },
    { name: 'Orbit', logo: 'O' },
  ]

  const [text, setText] = useState('')
  const [wordIndex, setWordIndex] = useState(0)
  const [deleting, setDeleting] = useState(false)

  useEffect(() => {
    const word = words[wordIndex]
    const timeout = setTimeout(() => {
      if (!deleting && text === word) {
        setDeleting(true)
      } else if (deleting && text === '') {
        setDeleting(false)
        setWordIndex(i => (i + 1) % words.length)
      } else {
        setText(prev => deleting ? prev.slice(0, -1) : word.slice(0, prev.length + 1))
      }
    }, deleting ? 50 : text === word ? 2000 : 100)
    return () => clearTimeout(timeout)
  }, [text, deleting, wordIndex])

  return (
    <section id="home" className="relative min-h-screen flex items-center pt-28 pb-20 overflow-hidden">
      {/* Floating decorative blobs */}
      <div className="absolute top-1/4 left-[15%] w-[500px] h-[500px] bg-nova-500/10 rounded-full blur-[120px] animate-float-slow pointer-events-none" />
      <div className="absolute bottom-1/3 right-[10%] w-[400px] h-[400px] bg-purple-500/10 rounded-full blur-[120px] animate-float-slow pointer-events-none" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-br from-nova-500/5 to-transparent rounded-full blur-[150px] animate-float-slow pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left content */}
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            className="text-center lg:text-left"
          >
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.5 }}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-sm font-medium text-nova-500 mb-8 premium-badge"
            >
              <span className="w-2 h-2 rounded-full bg-nova-500 animate-pulse" />
              {t('hero.badge')}
            </motion.div>

            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-bold tracking-tight text-balance leading-[1.05]">
              <span className="text-foreground">{t('hero.heading1')}</span>
              <br />
              <span className="gradient-text">{t('hero.heading2')}</span>
              <br />
              <span className="gradient-text">{text}<span className="inline-block w-[3px] h-[0.8em] bg-nova-500 ml-1 animate-pulse" /></span>
            </h1>

            <p className="mt-6 text-lg md:text-xl text-foreground/60 leading-relaxed max-w-xl mx-auto lg:mx-0">
              {t('hero.subtitle')}
            </p>

            <div className="flex items-center gap-4 mt-8 justify-center lg:justify-start">
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => document.getElementById('pricing')?.scrollIntoView({ behavior: 'smooth' })}
                className="relative h-12 px-8 rounded-xl bg-gradient-to-b from-nova-500 to-nova-600 text-white text-base font-medium shadow-lg shadow-nova-500/20 hover:shadow-xl hover:shadow-nova-500/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-500 flex items-center gap-2 group overflow-hidden"
              >
                <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/15 to-transparent skew-x-[-20deg]" />
                <span className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none -z-20 blur-xl bg-[conic-gradient(from_0deg,#6366f1,#a855f7,#ec4899,#6366f1)] animate-[spin_3s_linear_infinite]" />
                <span className="absolute inset-0 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none border border-white/20" />
                <span className="relative z-10 inline-flex items-center gap-2">
                  <Zap size={16} />
                  {t('hero.cta')}
                </span>
                <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 rounded-xl" />
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.96 }}
                onClick={() => document.getElementById('showcase')?.scrollIntoView({ behavior: 'smooth' })}
                className="relative h-12 px-8 rounded-xl glass-deep text-base font-medium flex items-center gap-2 transition-all duration-500 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 group overflow-hidden"
              >
                <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/15 to-transparent skew-x-[-20deg]" />
                <span className="relative z-10 inline-flex items-center gap-2">
                  <Play size={16} />
                  {t('hero.watchDemo')}
                </span>
                <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 rounded-xl" />
              </motion.button>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-2 sm:grid-cols-4 gap-8">
              {stats.map((stat, i) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + i * 0.1, duration: 0.5 }}
                  className="text-center premium-card p-4 rounded-xl hover:scale-105 transition-all duration-300"
                >
                  <AnimatedCounter value={stat.value} suffix={stat.suffix} />
                  <div className="text-sm text-foreground/50 mt-1">{stat.label}</div>
                </motion.div>
              ))}
            </div>

            {/* Companies */}
            <div className="mt-16">
              <p className="text-sm text-foreground/40 mb-6 uppercase tracking-widest font-medium text-center lg:text-left">{t('hero.trustedBy')}</p>
              <div className="glass-container rounded-xl p-6">
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-8 md:gap-12">
                  {companies.map(c => (
                    <div key={c.name} className="flex items-center gap-2 text-foreground/30 hover:text-foreground/60 transition-all duration-300 hover:scale-105">
                      <div className="premium-icon-wrapper w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center text-sm font-bold">{c.logo}</div>
                      <span className="text-sm font-medium">{c.name}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Right — 3D Dashboard preview */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.9, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
            className="relative hidden lg:block"
          >
            <div className="spotlight premium-card-glow premium-card-border glass-card rounded-3xl p-2 shadow-2xl shadow-nova-500/10 glow-nova hover:scale-[1.01] transition-transform duration-500">
              <div className="rounded-2xl bg-gradient-to-br from-nova-500/5 via-purple-500/5 to-pink-500/5 overflow-hidden">
                <div className="p-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-rose-500" />
                      <div className="w-3 h-3 rounded-full bg-amber-500" />
                      <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    </div>
                    <span className="text-xs text-foreground/40 font-mono">nexai.app/dashboard</span>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="glass-deep rounded-xl p-4">
                      <div className="text-xs text-foreground/40">Revenue</div>
                      <div className="text-2xl font-bold gradient-text">$128.4k</div>
                      <div className="text-xs text-emerald-500">+23.5% vs last month</div>
                    </div>
                    <div className="glass-deep rounded-xl p-4">
                      <div className="text-xs text-foreground/40">Users</div>
                      <div className="text-2xl font-bold">52.1k</div>
                      <div className="text-xs text-emerald-500">+12.3% vs last month</div>
                    </div>
                  </div>
                  <div className="glass-deep rounded-xl p-4">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs text-foreground/40">Active Projects</span>
                      <span className="text-xs text-nova-500 font-medium">+3 new</span>
                    </div>
                    <div className="space-y-2">
                      {['AI Automation', 'Analytics Engine', 'Customer Insights'].map((name, i) => (
                        <motion.div
                          key={name}
                          initial={{ width: 0 }}
                          animate={{ width: `${85 - i * 15}%` }}
                          transition={{ duration: 1, delay: 0.8 + i * 0.1 }}
                          className="h-2 rounded-full bg-gradient-to-r from-nova-500 to-purple-500"
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <div className="absolute -top-4 -right-4 w-16 h-16 animate-float-slow">
              <div className="w-full h-full rounded-2xl bg-gradient-to-br from-amber-500 to-rose-500 flex items-center justify-center text-white font-bold text-lg shadow-xl premium-card-border">
                AI
              </div>
            </div>

            {/* Orbiting ring */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="w-full h-full rounded-full border border-nova-500/10 animate-orbit" />
            </div>
          </motion.div>
        </div>

        {/* Scroll indicator */}
        <motion.button
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, y: [0, 6, 0] }}
          transition={{ opacity: { delay: 1.5 }, y: { duration: 2, repeat: Infinity } }}
          onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-foreground/30 hover:text-foreground/60 transition-all duration-300 hover:scale-110"
          aria-label={t('hero.scrollTo')}
        >
          <ArrowDown size={20} />
        </motion.button>
      </div>
    </section>
  )
}
