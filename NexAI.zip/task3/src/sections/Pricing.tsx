import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { SectionHeader } from '@/components/ui/Section'
import { Check, Sparkles } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

export default function Pricing() {
  const { t } = useLanguage()

  const plans = [
    {
      name: t('pricing.starterName'),
      monthly: 29,
      yearly: 290,
      desc: t('pricing.starterDesc'),
      features: ['5 users', '10k API calls/mo', 'Basic analytics', 'Community support', '2 projects'],
      popular: false,
    },
    {
      name: t('pricing.proName'),
      monthly: 99,
      yearly: 990,
      desc: t('pricing.proDesc'),
      features: ['25 users', '100K API calls/mo', 'Advanced analytics', 'Priority support', 'Unlimited projects', 'Custom reports', 'SSO'],
      popular: true,
    },
    {
      name: t('pricing.enterpriseName'),
      monthly: 299,
      yearly: 2990,
      desc: t('pricing.enterpriseDesc'),
      features: ['Unlimited users', '10M API calls/mo', 'Real-time analytics', '24/7 dedicated support', 'Custom integrations', 'Advanced SSO', 'Audit logs', 'SLA guarantee'],
      popular: false,
    },
]

  const [yearly, setYearly] = useState(false)

  return (
    <section id="pricing" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-1/3 right-0 w-96 h-96 bg-nova-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 left-[10%] w-72 h-72 bg-purple-500/5 rounded-full blur-3xl pointer-events-none animate-float-slow" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          title={t('section.pricing.title')}
          subtitle={t('section.pricing.subtitle')}
          badge={t('section.pricing.badge')}
        />

        {/* Toggle */}
        <div className="flex items-center justify-center gap-4 mb-14">
          <span className={`text-sm font-medium transition-colors duration-300 ${yearly ? 'text-foreground/40' : 'text-foreground'}`}>
            {t('pricing.monthly')}
          </span>
          <button
            onClick={() => setYearly(y => !y)}
            className={`relative w-14 h-7 rounded-full transition-all duration-300 ${
              yearly ? 'bg-nova-500 shadow-md shadow-nova-500/20' : 'bg-foreground/15 dark:bg-foreground/10'
            }`}
          >
            <motion.div
              className="absolute top-0.5 w-6 h-6 rounded-full bg-white shadow-lg"
              animate={{
                left: yearly ? 'calc(100% - 7px)' : '3px',
                scale: yearly ? [1, 1.1, 1] : [1, 1.1, 1],
              }}
              transition={{ type: 'spring', stiffness: 500, damping: 30 }}
            />
          </button>
          <span className={`text-sm font-medium transition-colors duration-300 ${yearly ? 'text-foreground' : 'text-foreground/40'}`}>
            {t('pricing.yearly')}{' '}
            <span className="text-nova-500 font-semibold bg-nova-500/10 px-2 py-0.5 rounded-full text-xs">
              {t('pricing.save')}
            </span>
          </span>
        </div>

        {/* Cards */}
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {plans.map((plan, i) => {
            const price = yearly ? plan.yearly : plan.monthly
            return (
              <motion.div
                key={plan.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                className={`relative rounded-2xl ${
                  plan.popular ? 'bg-gradient-to-br from-nova-500 to-purple-600 shadow-2xl shadow-nova-500/20 scale-[1.02] md:scale-105' : ''
                }`}
              >
                {plan.popular && (
                  <>
                    <div className="absolute -top-0.5 left-1/2 -translate-x-1/2 premium-badge premium-badge-glow z-10 whitespace-nowrap">
                      <Sparkles size={12} />
                      {t('pricing.popular')}
                    </div>
                    <div className="absolute inset-0 rounded-2xl opacity-30 blur-xl bg-gradient-to-br from-nova-500 to-purple-600 pointer-events-none" />
                  </>
                )}

                <div
                  className={`h-full rounded-2xl p-6 md:p-8 relative overflow-hidden ${
                    plan.popular
                      ? 'bg-white/70 dark:bg-white/[0.04] backdrop-blur-2xl shadow-lg shadow-nova-500/5 border border-white/60 dark:border-white/5'
                      : 'premium-card'
                  }`}
                >
                  {plan.popular && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-nova-500/[0.03] via-purple-500/[0.02] to-pink-500/[0.03] pointer-events-none" />
                  )}
                  {/* Shine overlay */}
                  <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/5 to-transparent skew-x-[-20deg] pointer-events-none" />

                  <h3 className="text-xl font-bold">{plan.name}</h3>
                  <div className="mt-5 flex items-baseline gap-1">
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={yearly ? 'y' : 'm'}
                        initial={{ y: 10, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -10, opacity: 0 }}
                        className="text-5xl font-bold tracking-tight"
                      >
                        ${price}
                      </motion.span>
                    </AnimatePresence>
                    <span className="text-foreground/40 text-sm">{t('pricing.perMonth')}</span>
                  </div>
                  {yearly && (
                    <div className="text-xs text-foreground/40 mt-1">
                      ${plan.monthly * 12}/yr billed annually
                    </div>
                  )}
                  <p className="text-sm text-foreground/60 mt-5 leading-relaxed">{plan.desc}</p>

                  <ul className="mt-8 space-y-3.5">
                    {plan.features.map(f => (
                      <li key={f} className="flex items-center gap-3 text-sm text-foreground/70">
                        <span className="premium-check shrink-0">
                          <Check size={10} strokeWidth={3} />
                        </span>
                        {f}
                      </li>
                    ))}
                  </ul>

                  <button
                    className={`mt-8 w-full h-12 rounded-xl text-base font-medium transition-all duration-500 relative overflow-hidden group ${
                      plan.popular
                        ? 'bg-gradient-to-b from-nova-500 to-nova-600 text-white shadow-lg shadow-nova-500/20 hover:shadow-xl hover:shadow-nova-500/30 hover:-translate-y-0.5 active:translate-y-0'
                        : 'glass-deep hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0'
                    }`}
                  >
                    <span className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent skew-x-[-20deg]" />
                    <span className="relative z-10">{t('pricing.cta')}</span>
                    <span className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-500 rounded-xl" />
                  </button>
                </div>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
