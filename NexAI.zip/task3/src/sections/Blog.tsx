import { motion } from 'framer-motion'
import { Section, SectionHeader } from '@/components/ui/Section'
import { Button } from '@/components/ui/Button'
import { blogPosts } from '@/data'
import { ArrowRight, Clock, User } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

export default function Blog() {
  const { t } = useLanguage()
  return (
    <section id="blog" className="relative py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge={t('section.blog.badge')}
          title={t('section.blog.title')}
          subtitle={t('section.blog.subtitle')}
        />

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post, i) => (
            <motion.article
              key={post.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
              className="group"
            >
              <a href="#" className="block premium-card premium-card-hover spotlight premium-card-glow rounded-2xl overflow-hidden h-full">
                <div className="aspect-[16/9] bg-gradient-to-br from-nova-500/10 via-purple-500/10 to-pink-500/10 flex items-center justify-center overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-t from-black/5 to-transparent" />
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center text-white text-2xl font-bold group-hover:scale-110 group-hover:rotate-3 transition-transform duration-500 shadow-lg shadow-nova-500/20">
                    <svg className="w-7 h-7" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
                      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                      <polyline points="14 2 14 8 20 8" />
                      <line x1="16" y1="13" x2="8" y2="13" />
                      <line x1="16" y1="17" x2="8" y2="17" />
                      <polyline points="10 9 9 9 8 9" />
                    </svg>
                  </div>
                </div>
                <div className="p-6 space-y-3.5">
                  <div className="flex items-center gap-2.5">
                    <span className="px-3 py-1 rounded-full bg-nova-500/10 text-nova-500 text-xs font-semibold tracking-wide uppercase">
                      {post.category}
                    </span>
                    <span className="flex items-center gap-1.5 text-xs text-foreground/40">
                      <Clock size={13} />
                      <span className="font-medium">{post.readingTime}</span>
                    </span>
                  </div>
                  <h3 className="text-base font-semibold leading-snug group-hover:text-nova-500 transition-colors duration-300">
                    {post.title}
                  </h3>
                  <p className="text-sm text-foreground/50 leading-relaxed line-clamp-2">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between pt-4 border-t border-black/5 dark:border-white/10">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center text-white text-[11px] font-bold ring-2 ring-white/50 dark:ring-white/10 shadow-sm">
                        {post.authorAvatar}
                      </div>
                      <div className="flex flex-col">
                        <span className="text-xs font-medium text-foreground/70">{post.author}</span>
                        <span className="text-[10px] text-foreground/30">{post.date}</span>
                      </div>
                    </div>
                    <span className="flex items-center gap-1.5 text-xs text-nova-500 font-semibold group-hover:gap-3 transition-all duration-300">
                      {t('blog.read')} <ArrowRight size={13} />
                    </span>
                  </div>
                </div>
              </a>
            </motion.article>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mt-12"
        >
          <Button variant="secondary">
            {t('blog.viewAll')}
            <ArrowRight size={16} />
          </Button>
        </motion.div>
      </div>
    </section>
  )
}