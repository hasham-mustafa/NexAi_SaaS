import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Section, SectionHeader } from '@/components/ui/Section'
import { faqs } from '@/data'
import { ChevronDown, Search } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

export default function FAQ() {
  const { t } = useLanguage()
  const categories = [
    { id: 'all', label: t('faq.all') },
    { id: 'product', label: t('faq.product') },
    { id: 'billing', label: t('faq.billing') },
    { id: 'security', label: t('faq.security') },
    { id: 'enterprise', label: t('faq.enterprise') },
  ]
  const [openId, setOpenId] = useState<string | null>(null)
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('all')

  const filtered = faqs.filter(
    (faq) =>
      (category === 'all' || faq.category === category) &&
      (faq.question.toLowerCase().includes(search.toLowerCase()) ||
        faq.answer.toLowerCase().includes(search.toLowerCase()))
  )

  return (
    <section id="faq" className="relative py-24 md:py-32">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge={t('section.faq.badge')}
          title={t('section.faq.title')}
          subtitle={t('section.faq.subtitle')}
        />

        <div className="relative mb-8">
          <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-foreground/30" />
          <input
            type="text"
            placeholder={t('faq.search')}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full h-12 pl-11 pr-4 rounded-xl glass text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30 focus:shadow-lg focus:shadow-nova-500/5 transition-all"
          />
        </div>

        <div className="flex justify-center mb-8">
          <div className="inline-flex p-1.5 rounded-2xl glass gap-1">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategory(cat.id)}
                className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                  category === cat.id
                    ? 'bg-nova-600 text-white shadow-lg shadow-nova-500/25'
                    : 'text-foreground/60 hover:text-foreground hover:bg-foreground/5'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-3">
          <AnimatePresence mode="wait">
            {filtered.length === 0 ? (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center text-foreground/40 py-12"
              >
                {t('faq.noResults')}
              </motion.p>
            ) : (
              filtered.map((faq) => (
                <motion.div key={faq.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}>
                  <div
                    onClick={() => setOpenId(openId === faq.id ? null : faq.id)}
                    role="button"
                    tabIndex={0}
                    onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setOpenId(openId === faq.id ? null : faq.id) } }}
                    aria-expanded={openId === faq.id}
                    aria-controls={`faq-answer-${faq.id}`}
                    className="w-full premium-card premium-card-hover spotlight p-5 text-left transition-all duration-300 cursor-pointer group"
                  >
                    {openId === faq.id && (
                      <div className="absolute left-0 top-0 bottom-0 w-[3px] bg-gradient-to-b from-nova-500 to-purple-500" />
                    )}
                    <div className="flex items-center justify-between gap-4">
                      <span className="text-base md:text-lg font-semibold">{faq.question}</span>
                      <motion.div
                        animate={{ rotate: openId === faq.id ? 180 : 0 }}
                        transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                        className="shrink-0 w-8 h-8 rounded-lg bg-foreground/5 flex items-center justify-center group-hover:bg-foreground/10 transition-colors"
                      >
                        <ChevronDown size={16} className="text-foreground/40 group-hover:text-foreground/60 transition-colors" />
                      </motion.div>
                    </div>
                    <AnimatePresence>
                      {openId === faq.id && (
                        <motion.div
                          id={`faq-answer-${faq.id}`}
                          role="region"
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                          className="overflow-hidden"
                        >
                          <p className="mt-4 text-sm md:text-base text-foreground/60 leading-relaxed">{faq.answer}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  )
}
