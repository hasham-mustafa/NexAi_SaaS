import { useEffect, useRef, useState, useCallback } from 'react'
import { motion } from 'framer-motion'
import { TiltCard } from '@/components/ui/TiltCard'
import { SectionHeader } from '@/components/ui/Section'
import { testimonials } from '@/data'
import { Star, ChevronLeft, ChevronRight, Quote, BadgeCheck } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

export default function Testimonials() {
  const { t } = useLanguage()
  const ref = useRef<HTMLDivElement>(null)
  const [idx, setIdx] = useState(0)
  const total = testimonials.length

  const go = useCallback((i: number) => {
    const el = ref.current
    if (!el) return
    const card = el.children[i] as HTMLElement | undefined
    if (!card) return
    el.scrollTo({ left: card.offsetLeft - el.offsetLeft, behavior: 'smooth' })
    setIdx(i)
  }, [])

  const dir = useCallback((d: 'left' | 'right') => go(d === 'left' ? (idx - 1 + total) % total : (idx + 1) % total), [idx, total, go])

  useEffect(() => {
    const el = ref.current
    if (!el) return
    let interval: ReturnType<typeof setInterval> | null = null

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          interval = setInterval(() => dir('right'), 4000)
        } else if (interval) {
          clearInterval(interval)
          interval = null
        }
      },
      { threshold: 0.3 }
    )
    observer.observe(el)
    return () => {
      observer.disconnect()
      if (interval) clearInterval(interval)
    }
  }, [dir])

  useEffect(() => {
    const el = ref.current
    if (!el) return
    let ticking = false
    const onScroll = () => {
      if (!ticking) {
        ticking = true
        requestAnimationFrame(() => {
          const w = (el!.children[0] as HTMLElement | undefined)?.offsetWidth ?? 340
          setIdx(Math.round(el!.scrollLeft / (w + 24)))
          ticking = false
        })
      }
    }
    el.addEventListener('scroll', onScroll, { passive: true })
    return () => el.removeEventListener('scroll', onScroll)
  }, [total])

  return (
    <section id="testimonials" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-0 right-0 w-96 h-96 bg-nova-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge={t('section.testimonials.badge')}
          title={t('section.testimonials.title')}
          subtitle={t('section.testimonials.subtitle')}
        />

        <div className="relative">
          <div ref={ref} className="flex gap-6 pb-4 overflow-x-auto scrollbar-hide snap-x snap-mandatory">
            {testimonials.map((t, i) => (
              <motion.div
                key={t.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="min-w-[340px] md:min-w-[400px] snap-start"
              >
                <TiltCard intensity={8}>
                  <div className="premium-card premium-card-hover premium-card-border spotlight rounded-2xl p-6 md:p-8 h-full group">
                    <Quote size={20} className="text-nova-500/20 absolute top-5 right-5" />

                    <div className="flex items-center gap-1 mb-4">
                      {Array.from({ length: 5 }).map((_, j) => (
                        <Star
                          key={j}
                          size={14}
                          className={j < t.rating ? 'text-amber-500 fill-amber-500 drop-shadow-[0_0_4px_rgba(245,158,11,0.3)]' : 'text-foreground/10'}
                        />
                      ))}
                    </div>

                    <p className="text-sm md:text-base text-foreground/70 leading-relaxed mb-6 italic">&ldquo;{t.content}&rdquo;</p>

                    <div className="flex items-center gap-3 mt-auto">
                      <div className="w-11 h-11 rounded-full bg-gradient-to-br from-nova-500 via-purple-500 to-pink-500 p-[2px] shrink-0">
                        <div className="w-full h-full rounded-full bg-[#0a0a0f] flex items-center justify-center text-white text-sm font-bold">
                          {t.avatar}
                        </div>
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="text-sm font-semibold truncate">{t.name}</span>
                          <BadgeCheck size={14} className="text-nova-500 shrink-0" />
                        </div>
                        <div className="text-xs text-foreground/40 truncate">{t.role}, {t.company}</div>
                      </div>
                    </div>
                  </div>
                </TiltCard>
              </motion.div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-6 mt-10">
            <button onClick={() => dir('left')} className="w-11 h-11 rounded-xl glass flex items-center justify-center text-foreground/60 hover:text-foreground transition-all hover:shadow-lg hover:border-nova-500/20 active:scale-95" aria-label={t('common.previous')}>
              <ChevronLeft size={18} />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button key={i} onClick={() => go(i)} className={`h-2 rounded-full transition-all duration-300 ${i === idx ? 'bg-nova-500 w-6' : 'w-2 bg-foreground/20 hover:bg-foreground/40'}`} aria-label={`Go to ${i + 1}`} />
              ))}
            </div>
            <button onClick={() => dir('right')} className="w-11 h-11 rounded-xl glass flex items-center justify-center text-foreground/60 hover:text-foreground transition-all hover:shadow-lg hover:border-nova-500/20 active:scale-95" aria-label={t('common.next')}>
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  )
}