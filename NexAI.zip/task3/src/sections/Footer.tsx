import { motion } from 'framer-motion'
import { ArrowUp, Mail } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

const socials = [
  { name: 'Twitter', path: 'M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z' },
  { name: 'LinkedIn', path: 'M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z' },
  { name: 'GitHub', path: 'M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0112 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z' },
  { name: 'YouTube', path: 'M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.5 9.376.5 9.376.5s7.505 0 9.377-.5a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z' },
]

export default function Footer() {
  const { t } = useLanguage()

  const footerLinks = [
    { title: t('footer.product'), links: [t('footer.features'), t('footer.pricing'), t('footer.showcase'), t('footer.integrations'), t('footer.changelog')] },
    { title: t('footer.company'), links: [t('footer.about'), t('footer.blog'), t('footer.careers'), t('footer.press'), t('footer.partners')] },
    { title: t('footer.support'), links: [t('footer.documentation'), t('footer.apiReference'), t('footer.tutorials'), t('footer.status'), t('footer.contact')] },
    { title: t('footer.legal'), links: [t('footer.privacy'), t('footer.terms'), t('footer.cookies'), t('footer.gdpr'), t('footer.security')] },
  ]
  return (
    <footer className="relative border-t border-black/5 dark:border-white/10 bg-gradient-to-b from-foreground/[0.01] to-foreground/[0.03] dark:from-transparent dark:to-white/[0.02]">
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-nova-500/[0.02] to-transparent dark:via-nova-500/[0.03] pointer-events-none" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-20 relative">
        <div className="grid sm:grid-cols-2 lg:grid-cols-6 gap-8 lg:gap-12">
          <div className="lg:col-span-2 space-y-6">
            <a href="#" className="flex items-center gap-2.5 group">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-nova-500 to-purple-600 flex items-center justify-center text-white font-bold text-sm">N</div>
              <span className="text-lg font-bold tracking-tight">NexAI</span>
            </a>
            <p className="text-sm text-foreground/40 leading-relaxed max-w-xs">
              {t('footer.tagline')}
            </p>
            <div className="flex gap-2">
              {socials.map(s => (
                <a key={s.name} href="#" className="w-9 h-9 rounded-xl bg-gradient-to-br from-foreground/[0.04] to-foreground/[0.02] dark:from-white/[0.04] dark:to-white/[0.02] flex items-center justify-center text-foreground/30 hover:from-nova-500 hover:to-purple-600 hover:text-white hover:shadow-lg hover:shadow-nova-500/20 hover:-translate-y-0.5 transition-all duration-300" aria-label={t('footer.' + s.name.toLowerCase() as any)}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d={s.path} /></svg>
                </a>
              ))}
            </div>
          </div>

          {footerLinks.map(g => (
            <div key={g.title}>
              <h4 className="text-sm font-semibold mb-4 tracking-tight">{g.title}</h4>
              <ul className="space-y-3">
                {g.links.map(l => (
                  <li key={l}>
                    <a href="#" className="text-sm text-foreground/40 hover:text-nova-500 transition-all duration-300 relative inline-block after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[1.5px] after:bg-nova-500 after:transition-all after:duration-300 hover:after:w-full">{l}</a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-black/5 dark:border-white/10 relative before:content-[''] before:absolute before:top-[-1px] before:left-1/4 before:right-1/4 before:h-[1px] before:bg-gradient-to-r before:from-transparent before:via-nova-500/20 before:to-transparent">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
            <div className="max-w-sm w-full">
              <label className="text-xs font-medium text-foreground/60 mb-2 block tracking-wide">{t('footer.stayUpdated')}</label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Mail size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-foreground/30" />
                  <input type="email" placeholder={t('footer.emailPlaceholder')} className="w-full h-10 pl-9 pr-3 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-xl border border-white/40 dark:border-white/10 text-sm outline-none focus:border-nova-500/50 focus:ring-1 focus:ring-nova-500/30 transition-all duration-300 hover:border-nova-500/20" />
                </div>
                <button className="h-10 px-4 rounded-xl bg-gradient-to-b from-nova-500 to-nova-600 text-white text-sm font-medium hover:from-nova-400 hover:to-nova-500 hover:shadow-lg hover:shadow-nova-500/20 transition-all duration-300 shrink-0">{t('footer.subscribe')}</button>
              </div>
            </div>
            <p className="text-xs text-foreground/40 tracking-wide">&copy; {new Date().getFullYear()} NexAI. {t('footer.copyright')}</p>
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="flex items-center gap-1.5 text-xs text-foreground/40 hover:text-nova-500 hover:gap-2 transition-all duration-300 group font-medium">
              {t('footer.backToTop')} <ArrowUp size={12} className="group-hover:-translate-y-0.5 transition-transform duration-300" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  )
}