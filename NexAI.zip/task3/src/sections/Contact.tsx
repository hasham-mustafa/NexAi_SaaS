import { useState } from 'react'
import { motion } from 'framer-motion'
import { Button } from '@/components/ui/Button'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { SectionHeader } from '@/components/ui/Section'
import { Send, CheckCircle, Mail, Phone, MapPin } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

function LinkedinIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2zM4 6a2 2 0 100-4 2 2 0 000 4z" />
    </svg>
  )
}

function GithubLogo() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M9 19c-5 1.5-5-2.5-7-3m14 6v-3.87a3.37 3.37 0 00-.94-2.61c3.14-.35 6.44-1.54 6.44-7A5.44 5.44 0 0020 4.77 5.07 5.07 0 0019.91 1S18.73.65 16 2.48a13.38 13.38 0 00-7 0C6.27.65 5.09 1 5.09 1A5.07 5.07 0 005 4.77a5.44 5.44 0 00-1.5 3.78c0 5.42 3.3 6.61 6.44 7A3.37 3.37 0 009 18.13V22" />
    </svg>
  )
}

export default function Contact() {
  const { t } = useLanguage()
  const schema = z.object({
    name: z.string().min(2, t('contact.nameError')),
    email: z.string().email(t('contact.emailError')),
    subject: z.string().min(5, t('contact.subjectError')),
    message: z.string().min(10, t('contact.messageError')),
  })
  type FormData = z.infer<typeof schema>
  const [submitted, setSubmitted] = useState(false)
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<FormData>({
    resolver: zodResolver(schema),
  })

  const onSubmit = async () => {
    await new Promise(r => setTimeout(r, 1500))
    setSubmitted(true)
    reset()
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <section id="contact" className="relative py-24 md:py-32">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          title={t('section.contact.title')}
          subtitle={t('section.contact.subtitle')}
          badge={t('section.contact.badge')}
        />

        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
          >
            <form onSubmit={handleSubmit(onSubmit)} className="premium-card-border spotlight rounded-2xl p-6 md:p-8 space-y-5 bg-white/70 dark:bg-[rgba(255,255,255,0.02)] backdrop-blur-[32px]">
              {submitted ? (
                <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
                  <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 flex items-center justify-center mx-auto mb-4">
                    <CheckCircle size={32} className="text-emerald-500" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">{t('contact.success')}</h3>
                  <p className="text-sm text-foreground/50">{t('contact.successDesc')}</p>
                </motion.div>
              ) : (
                <>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground/60">{t('contact.name')}</label>
                      <input {...register('name')} placeholder={t('contact.namePlaceholder')} className="w-full h-11 px-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-xl border border-white/40 dark:border-white/10 text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30 transition-all duration-300 hover:border-nova-500/20 focus:border-nova-500/40" />
                      {errors.name && <p className="text-xs text-rose-500">{errors.name.message}</p>}
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground/60">{t('contact.email')}</label>
                      <input {...register('email')} placeholder={t('contact.emailPlaceholder')} className="w-full h-11 px-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-xl border border-white/40 dark:border-white/10 text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30 transition-all duration-300 hover:border-nova-500/20 focus:border-nova-500/50" />
                      {errors.email && <p className="text-xs text-rose-500">{errors.email.message}</p>}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground/60">{t('contact.subject')}</label>
                    <input {...register('subject')} placeholder={t('contact.subjectPlaceholder')} className="w-full h-11 px-4 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-xl border border-white/40 dark:border-white/10 text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30 transition-all duration-300 hover:border-nova-500/20 focus:border-nova-500/50" />
                    {errors.subject && <p className="text-xs text-rose-500">{errors.subject.message}</p>}
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground/60">{t('contact.message')}</label>
                    <textarea {...register('message')} rows={5} placeholder={t('contact.messagePlaceholder')} className="w-full px-4 py-3 rounded-xl bg-white/60 dark:bg-white/5 backdrop-blur-xl border border-white/40 dark:border-white/10 text-sm focus:outline-none focus:ring-2 focus:ring-nova-500/30 transition-all duration-300 hover:border-nova-500/20 focus:border-nova-500/50 resize-none" />
                    {errors.message && <p className="text-xs text-rose-500">{errors.message.message}</p>}
                  </div>
                  <Button type="submit" variant="primary" className="w-full h-12" loading={isSubmitting}>
                    <Send size={16} />
                    {t('contact.sendMessage')}
                  </Button>
                </>
              )}
            </form>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            className="space-y-6"
          >
            <div className="premium-card rounded-2xl p-6 space-y-5">
              <h3 className="text-lg font-semibold">{t('contact.info')}</h3>
              <div className="space-y-4">
                {[
                  { icon: Mail, label: 'Email', value: t('contact.emailValue') },
                  { icon: Phone, label: 'Phone', value: t('contact.phoneValue') },
                  { icon: MapPin, label: 'Address', value: t('contact.addressValue') },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex items-start gap-3 group cursor-default">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-nova-500/10 to-purple-500/10 flex items-center justify-center shrink-0 group-hover:from-nova-500/20 group-hover:to-purple-500/20 transition-all duration-300">
                      <Icon size={18} className="text-nova-500 group-hover:scale-110 transition-transform duration-300" />
                    </div>
                    <div>
                      <div className="text-xs text-foreground/40 font-medium">{label}</div>
                      <div className="text-sm font-medium text-foreground/80">{value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="premium-card rounded-2xl p-6">
              <h3 className="text-lg font-semibold mb-4">{t('contact.followUs')}</h3>
              <div className="flex gap-3">
                <a href="#" className="w-10 h-10 rounded-xl bg-gradient-to-br from-nova-500/10 to-purple-500/10 flex items-center justify-center text-nova-500 hover:bg-gradient-to-br hover:from-nova-500 hover:to-purple-600 hover:text-white hover:shadow-lg hover:shadow-nova-500/20 hover:-translate-y-0.5 transition-all duration-300" aria-label="LinkedIn"><LinkedinIcon /></a>
                <a href="#" className="w-10 h-10 rounded-xl bg-gradient-to-br from-nova-500/10 to-purple-500/10 flex items-center justify-center text-nova-500 hover:bg-gradient-to-br hover:from-nova-500 hover:to-purple-600 hover:text-white hover:shadow-lg hover:shadow-nova-500/20 hover:-translate-y-0.5 transition-all duration-300" aria-label="Twitter">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M4 4l11.733 16h4.267l-11.733 -16zM4 20l6.768 -6.768M20 4l-6.768 6.768" />
                  </svg>
                </a>
                <a href="#" className="w-10 h-10 rounded-xl bg-gradient-to-br from-nova-500/10 to-purple-500/10 flex items-center justify-center text-nova-500 hover:bg-gradient-to-br hover:from-nova-500 hover:to-purple-600 hover:text-white hover:shadow-lg hover:shadow-nova-500/20 hover:-translate-y-0.5 transition-all duration-300" aria-label="GitHub"><GithubLogo /></a>
              </div>
            </div>

            <div className="premium-card rounded-2xl p-6 aspect-[16/9] flex items-center justify-center bg-gradient-to-br from-nova-500/5 via-purple-500/5 to-pink-500/5">
              <div className="text-center">
                <MapPin size={32} className="text-nova-500 mx-auto mb-2 animate-float-slow" />
                <p className="text-sm text-foreground/40 font-medium">San Francisco, CA</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}