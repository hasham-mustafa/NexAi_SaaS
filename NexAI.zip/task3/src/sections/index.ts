import { lazy } from 'react'
const lazily = (importFn: () => Promise<any>, name: string) =>
  lazy(() => importFn().then(m => ({ default: m[name] })))

export const Hero = lazily(() => import('./Hero'), 'Hero')
export const Features = lazily(() => import('./Features'), 'Features')
export const Showcase = lazily(() => import('./Showcase'), 'Showcase')
export const Pricing = lazily(() => import('./Pricing'), 'Pricing')
export const Comparison = lazily(() => import('./Comparison'), 'Comparison')
export const Testimonials = lazily(() => import('./Testimonials'), 'Testimonials')
export const FAQ = lazily(() => import('./FAQ'), 'FAQ')
export const Blog = lazily(() => import('./Blog'), 'Blog')
export const Contact = lazily(() => import('./Contact'), 'Contact')
export const Footer = lazily(() => import('./Footer'), 'Footer')