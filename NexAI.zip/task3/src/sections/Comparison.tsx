import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { SectionHeader } from '@/components/ui/Section'
import { comparisonFeatures } from '@/data'
import { Check, X, Info, ChevronDown } from 'lucide-react'
import { useLanguage } from '@/context/LanguageContext'

function getCategory(f: (typeof comparisonFeatures)[0]): string {
  const a = ['Analytics Dashboard', 'Custom Reports', 'Data Export', 'API Access']
  const t = ['Team Members', 'Collaboration']
  const s = ['SSO', 'Audit Logs', 'Data Encryption']
  const sp = ['Support', 'Training']
  if (a.includes(f.name)) return 'analytics'
  if (t.includes(f.name)) return 'team'
  if (s.includes(f.name)) return 'security'
  if (sp.includes(f.name)) return 'support'
  return 'core'
}

export default function Comparison() {
  const { t } = useLanguage()
  const categories = [
    { id: 'all', label: t('comparison.tabAll') },
    { id: 'core', label: t('comparison.tabCore') },
    { id: 'analytics', label: t('comparison.tabAnalytics') },
    { id: 'team', label: t('comparison.tabTeam') },
    { id: 'security', label: t('comparison.tabSecurity') },
    { id: 'support', label: t('comparison.tabSupport') },
  ]
  const [cat, setCat] = useState('all')
  const [expanded, setExpanded] = useState<Set<string>>(new Set())
  const filtered = cat === 'all' ? comparisonFeatures : comparisonFeatures.filter(f => getCategory(f) === cat)

  const toggle = (id: string) => {
    setExpanded(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  return (
    <section id="comparison" className="relative py-24 md:py-32">
      <div className="absolute top-1/2 left-0 w-72 h-72 bg-nova-500/5 rounded-full blur-3xl pointer-events-none animate-float-slow" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader title={t('section.comparison.title')} subtitle={t('section.comparison.subtitle')} badge={t('section.comparison.badge')} />

        {/* Category tabs */}
        <div className="flex flex-wrap gap-2 mb-10 justify-center">
          {categories.map(c => (
            <button
              key={c.id}
              onClick={() => setCat(c.id)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-300 ${
                cat === c.id
                  ? 'bg-gradient-to-r from-nova-500 to-purple-600 text-white shadow-lg shadow-nova-500/20'
                  : 'premium-card text-foreground/60 hover:text-foreground hover:shadow-sm'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-2xl border border-black/5 dark:border-white/5 shadow-sm bg-white/80 dark:bg-white/[0.015] backdrop-blur-xl">
          <table className="w-full">
            <thead>
              <tr className="border-b border-black/5 dark:border-white/5 bg-gradient-to-r from-nova-500/[0.02] via-purple-500/[0.02] to-transparent">
                <th className="text-left p-5 text-xs font-semibold tracking-wider uppercase text-foreground/40">{t('comparison.feature')}</th>
                {[t('pricing.starterName'), t('pricing.proName'), t('pricing.enterpriseName')].map((name, pi) => (
                  <th key={name} className={`p-5 text-center font-semibold text-sm ${pi === 1 ? 'text-nova-500' : 'text-foreground/60'}`}>
                    {name}
                    {pi === 1 && (
                      <div className="text-xs font-medium text-nova-500 bg-nova-500/10 px-2 py-0.5 rounded-full mt-1 inline-block">{t('comparison.bestValue')}</div>
                    )}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              <AnimatePresence mode="wait">
                {filtered.map((f, i) => (
                  <motion.tr
                    key={f.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ delay: i * 0.025, duration: 0.3 }}
                    className={`border-b border-black/[0.03] dark:border-white/5 last:border-0 transition-all duration-300 ${
                      expanded.has(f.id)
                        ? 'bg-nova-500/[0.015] dark:bg-nova-500/[0.04]'
                        : 'hover:bg-foreground/[0.02] dark:hover:bg-white/[0.02]'
                    } ${i % 2 === 0 && !expanded.has(f.id) ? 'bg-black/[0.01] dark:bg-white/[0.005]' : ''}`}
                  >
                    <td className="p-5 text-sm">
                      <button onClick={() => toggle(f.id)} className="flex items-center gap-2.5 w-full text-left group cursor-pointer">
                        <motion.span
                          animate={{ rotate: expanded.has(f.id) ? 0 : -90 }}
                          transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                          className="flex items-center justify-center w-5 h-5 rounded-md bg-foreground/5 text-foreground/30 group-hover:text-foreground/60 group-hover:bg-foreground/10 transition-all"
                        >
                          <ChevronDown size={12} strokeWidth={2} />
                        </motion.span>
                        <span className="font-medium text-foreground/80">{f.name}</span>
                        {f.tooltip && (
                          <span className="group/tooltip relative cursor-help ml-auto">
                            <Info size={13} className="text-foreground/20 group-hover:text-foreground/40 transition-colors" />
                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1.5 rounded-lg glass text-xs whitespace-nowrap opacity-0 group-hover/tooltip:opacity-100 transition-opacity pointer-events-none z-20 shadow-xl backdrop-blur-2xl">
                              {f.tooltip}
                            </span>
                          </span>
                        )}
                      </button>
                      <AnimatePresence>
                        {expanded.has(f.id) && f.description && (
                          <motion.p
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                            className="overflow-hidden text-xs text-foreground/40 mt-2.5 pl-7 leading-relaxed"
                          >
                            {f.description}
                          </motion.p>
                        )}
                      </AnimatePresence>
                    </td>
                    {f.plans.map((p, pi) => (
                      <td
                        key={p.name}
                        className={`p-5 text-center transition-colors ${pi === 1 ? 'bg-nova-500/[0.02] dark:bg-nova-500/[0.03]' : ''}`}
                      >
                        {typeof p.included === 'boolean' ? (
                          p.included ? (
                            <span className="premium-check inline-flex">
                              <Check size={10} strokeWidth={3} />
                            </span>
                          ) : (
                            <span className="premium-cross inline-flex">
                              <X size={10} strokeWidth={3} />
                            </span>
                          )
                        ) : (
                          <span className="text-sm font-semibold text-foreground/70">{p.included as string}</span>
                        )}
                      </td>
                    ))}
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
      </div>
    </section>
  )
}
