import { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { features as featuresData } from '@/data'
import { SectionHeader } from '@/components/ui/Section'
import { TiltCard } from '@/components/ui/TiltCard'
import { StaggerContainer, StaggerItem } from '@/components/ui/Reveal'
import { Zap, BarChart4, Users, Shield, Puzzle, Rocket, ChevronDown } from 'lucide-react'
import type { ElementType } from 'react'
import { useLanguage } from '@/context/LanguageContext'

const iconMap: Record<string, ElementType> = {
  Zap, BarChart3: BarChart4, Users, Shield, Blocks: Puzzle, Rocket,
}

const gradients = [
  ['from-nova-500', 'to-purple-600'],
]

function FeatureCard({ feature, index }: { feature: (typeof featuresData)[0]; index: number }) {
  const { t } = useLanguage()
  const [expanded, setExpanded] = useState(false)
  const Icon = iconMap[feature.icon]
  return (
    <StaggerItem>
      <TiltCard intensity={10} className="group h-full">
        <motion.div
          className="premium-card premium-card-hover premium-card-border rounded-2xl p-6 h-full flex flex-col spotlight cursor-pointer relative overflow-hidden"
          onClick={() => setExpanded(!expanded)}
        >
          <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
            {Icon && <Icon size={20} className="text-white" />}
          </div>
          <h3 className="mt-5 text-lg font-bold tracking-tight">{feature.title}</h3>
          <p className="mt-2 text-sm text-foreground/60 leading-relaxed flex-1">{feature.description}</p>
          <AnimatePresence>
            {expanded && (
              <motion.ul
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="mt-4 space-y-2 overflow-hidden"
              >
                {feature.details.map((d) => (
                  <li key={d} className="flex items-center gap-2 text-sm text-foreground/60">
                    <span className="w-1 h-1 rounded-full bg-nova-500 shrink-0" />
                    {d}
                  </li>
                ))}
              </motion.ul>
            )}
          </AnimatePresence>
          <div className="mt-4 flex items-center gap-1.5 text-xs font-medium text-nova-500">
            <span>{expanded ? t('common.showLess') : t('common.viewDetails')}</span>
            <motion.span animate={{ rotate: expanded ? 180 : 0 }}>
              <ChevronDown size={14} />
            </motion.span>
          </div>
        </motion.div>
      </TiltCard>
    </StaggerItem>
  )
}

export default function Features() {
  const { t } = useLanguage()
  return (
    <section id="features" className="relative py-24 md:py-32 overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-nova-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <SectionHeader
          badge={t('section.features.badge')}
          title={t('section.features.title')}
          subtitle={t('section.features.subtitle')}
        />
        <StaggerContainer className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {featuresData.map((f, i) => (
            <FeatureCard key={f.id} feature={f} index={i} />
          ))}
        </StaggerContainer>
      </div>
    </section>
  )
}