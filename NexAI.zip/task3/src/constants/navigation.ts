import type { NavItem } from '@/types'

export const navItems: NavItem[] = [
  { id: 'home', label: 'Home', href: '#home' },
  { id: 'features', label: 'Features', href: '#features' },
  { id: 'showcase', label: 'Product', href: '#showcase' },
  { id: 'pricing', label: 'Pricing', href: '#pricing' },
  { id: 'comparison', label: 'Comparison', href: '#comparison' },
  { id: 'testimonials', label: 'Testimonials', href: '#testimonials' },
  { id: 'faq', label: 'FAQ', href: '#faq' },
  { id: 'blog', label: 'Blog', href: '#blog' },
  { id: 'contact', label: 'Contact', href: '#contact' },
]