import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import type { Theme, AccentColor } from '@/types'

interface ThemeContextType {
  theme: Theme
  accentColor: AccentColor
  setTheme: (theme: Theme) => void
  setAccentColor: (color: AccentColor) => void
  toggleTheme: () => void
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined)

const accentColorMap: Record<AccentColor, string> = {
  violet: '#6366f1',
  blue: '#3b82f6',
  green: '#10b981',
  rose: '#f43f5e',
  amber: '#f59e0b',
}

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('nexai-theme')
    if (saved === 'light' || saved === 'dark') return saved
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
  })

  const [accentColor, setAccentColor] = useState<AccentColor>(() => {
    const saved = localStorage.getItem('nexai-accent')
    if (saved === 'violet' || saved === 'blue' || saved === 'green' || saved === 'rose' || saved === 'amber') return saved
    return 'violet'
  })

  useEffect(() => {
    const root = document.documentElement
    if (theme === 'dark') {
      root.classList.add('dark')
    } else {
      root.classList.remove('dark')
    }
    root.style.setProperty('--color-accent', accentColorMap[accentColor])
    localStorage.setItem('nexai-theme', theme)
    localStorage.setItem('nexai-accent', accentColor)
  }, [theme, accentColor])

  const toggleTheme = () => setTheme(prev => prev === 'dark' ? 'light' : 'dark')

  return (
    <ThemeContext.Provider value={{ theme, accentColor, setTheme, setAccentColor, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  )
}

export function useTheme() {
  const context = useContext(ThemeContext)
  if (!context) throw new Error('useTheme must be used within ThemeProvider')
  return context
}