import type { Language } from '@/types'
import { en } from './en'
import { es } from './es'
import { fr } from './fr'
import { de } from './de'
import { ja } from './ja'
import { zh } from './zh'

export const locales: Record<Language, typeof en> = { en, es, fr, de, ja, zh }
