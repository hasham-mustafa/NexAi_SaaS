import type { Stat, Company } from '@/types'

export const stats: Stat[] = [
  { value: 50000, suffix: '+', label: 'Active Users' },
  { value: 1000, suffix: '+', label: 'Enterprise Clients' },
  { value: 99.9, suffix: '%', label: 'Uptime SLA' },
  { value: 150, suffix: 'M+', label: 'API Calls/Day' },
]

export const companies: Company[] = [
  { name: 'TechFlow', logo: 'T' },
  { name: 'ApexLabs', logo: 'A' },
  { name: 'Cipher', logo: 'C' },
  { name: 'Venture', logo: 'V' },
  { name: 'Pulse', logo: 'P' },
  { name: 'Orbit', logo: 'O' },
]