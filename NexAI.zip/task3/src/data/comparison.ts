import type { ComparisonFeature } from '@/types'

export const comparisonFeatures: ComparisonFeature[] = [
  {
    id: 'users',
    name: 'Team Members',
    plans: [
      { name: 'Starter', included: 'Up to 5' },
      { name: 'Professional', included: 'Up to 25' },
      { name: 'Enterprise', included: 'Unlimited' },
    ],
  },
  {
    id: 'api-calls',
    name: 'API Calls / Month',
    plans: [
      { name: 'Starter', included: '10,000' },
      { name: 'Professional', included: '100,000' },
      { name: 'Enterprise', included: 'Unlimited' },
    ],
  },
  {
    id: 'analytics',
    name: 'Advanced Analytics',
    plans: [
      { name: 'Starter', included: false },
      { name: 'Professional', included: true },
      { name: 'Enterprise', included: true },
    ],
  },
  {
    id: 'storage',
    name: 'Storage',
    plans: [
      { name: 'Starter', included: '1 GB' },
      { name: 'Professional', included: '50 GB' },
      { name: 'Enterprise', included: 'Unlimited' },
    ],
  },
  {
    id: 'support',
    name: 'Support Level',
    plans: [
      { name: 'Starter', included: 'Email' },
      { name: 'Professional', included: 'Priority' },
      { name: 'Enterprise', included: '24/7 Dedicated' },
    ],
  },
  {
    id: 'security',
    name: 'Advanced Security',
    tooltip: 'SOC 2, encryption, RBAC, audit logs',
    plans: [
      { name: 'Starter', included: false },
      { name: 'Professional', included: true },
      { name: 'Enterprise', included: true },
    ],
  },
  {
    id: 'integrations',
    name: 'Custom Integrations',
    plans: [
      { name: 'Starter', included: false },
      { name: 'Professional', included: false },
      { name: 'Enterprise', included: true },
    ],
  },
  {
    id: 'dedicated',
    name: 'Account Manager',
    plans: [
      { name: 'Starter', included: false },
      { name: 'Professional', included: false },
      { name: 'Enterprise', included: true },
    ],
  },
  {
    id: 'sla',
    name: 'Uptime SLA',
    plans: [
      { name: 'Starter', included: '99.9%' },
      { name: 'Professional', included: '99.99%' },
      { name: 'Enterprise', included: '99.999%' },
    ],
  },
]