import type { Testimonial } from '@/types'

export const testimonials: Testimonial[] = [
  {
    id: '1',
    name: 'Sarah Chen',
    role: 'CTO',
    company: 'AcmeCorp',
    avatar: 'SC',
    content: 'NexAI transformed our workflow automation. We reduced manual processing time by 87% in the first month alone. The intelligent agents are remarkably accurate.',
    rating: 5,
  },
  {
    id: '2',
    name: 'Marcus Johnson',
    role: 'VP of Engineering',
    company: 'TechFlow',
    avatar: 'MJ',
    content: 'The analytics capabilities are unmatched. We can now predict customer churn with 94% accuracy. This platform is a game-changer for data-driven teams.',
    rating: 5,
  },
  {
    id: '3',
    name: 'Elena Rodriguez',
    role: 'Head of Product',
    company: 'VentureLabs',
    avatar: 'ER',
    content: 'We evaluated 12 different AI platforms before choosing NexAI. The combination of security, scalability, and ease of use is simply unbeatable.',
    rating: 5,
  },
  {
    id: '4',
    name: 'David Kim',
    role: 'Engineering Manager',
    company: 'Orbit Systems',
    avatar: 'DK',
    content: 'The API documentation is incredible. Our team integrated the complete platform in just 3 days. The support team was responsive throughout.',
    rating: 4,
  },
  {
    id: '5',
    name: 'Lisa Thompson',
    role: 'Director of AI',
    company: 'Pulse Labs',
    avatar: 'LT',
    content: 'Finally, an AI platform that actually delivers on its promises. The predictive models have saved us millions in operational costs.',
    rating: 5,
  },
]