import type { Feature } from '@/types'

export const features: Feature[] = [
  {
    id: 'ai-automation',
    title: 'AI-Powered Automation',
    description: 'Automate complex workflows with intelligent agents that learn from your processes.',
    icon: 'Zap',
    gradient: 'from-violet-500 to-purple-600',
    details: [
      'Smart workflow automation',
      'Intelligent process learning',
      'Adaptive decision making',
      'Real-time optimization',
    ],
  },
  {
    id: 'analytics',
    title: 'Advanced Analytics',
    description: 'Deep insights with real-time dashboards and predictive analytics powered by ML.',
    icon: 'BarChart3',
    gradient: 'from-blue-500 to-cyan-600',
    details: [
      'Real-time dashboards',
      'Predictive analytics',
      'Custom report builder',
      'Data visualization',
    ],
  },
  {
    id: 'collaboration',
    title: 'Team Collaboration',
    description: 'Work together seamlessly with real-time collaboration and shared workspaces.',
    icon: 'Users',
    gradient: 'from-emerald-500 to-teal-600',
    details: [
      'Real-time editing',
      'Shared workspaces',
      'Version control',
      'Team chat & comments',
    ],
  },
  {
    id: 'security',
    title: 'Enterprise Security',
    description: 'Bank-grade encryption with SOC 2 compliance and advanced threat detection.',
    icon: 'Shield',
    gradient: 'from-rose-500 to-pink-600',
    details: [
      'End-to-end encryption',
      'SOC 2 Type II certified',
      'Advanced threat detection',
      'Role-based access control',
    ],
  },
  {
    id: 'integrations',
    title: 'Seamless Integrations',
    description: 'Connect with 200+ tools and platforms through our powerful API.',
    icon: 'Blocks',
    gradient: 'from-amber-500 to-orange-600',
    details: [
      '200+ native integrations',
      'REST & GraphQL APIs',
      'Webhook support',
      'Custom integrations',
    ],
  },
  {
    id: 'scalability',
    title: 'Infinite Scalability',
    description: 'Scale from startup to enterprise with auto-scaling infrastructure.',
    icon: 'Rocket',
    gradient: 'from-indigo-500 to-violet-600',
    details: [
      'Auto-scaling infrastructure',
      'Global CDN',
      'Load balancing',
      '99.99% uptime SLA',
    ],
  },
]