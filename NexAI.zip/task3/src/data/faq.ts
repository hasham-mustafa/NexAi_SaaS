import type { FAQ } from '@/types'

export const faqs: FAQ[] = [
  {
    id: '1',
    question: 'How does NexAI\'s automation work?',
    answer: 'NexAI uses advanced machine learning models to analyze your workflows and create intelligent automation agents. These agents learn from your team\'s patterns and gradually take over repetitive tasks, freeing your team to focus on high-impact work. The system becomes smarter over time through continuous learning.',
    category: 'product',
  },
  {
    id: '2',
    question: 'Is my data secure on NexAI?',
    answer: 'Absolutely. NexAI is SOC 2 Type II certified with bank-grade encryption at rest and in transit. We use advanced threat detection, role-based access control, and audit logging. Your data is isolated in dedicated instances and never shared with third parties.',
    category: 'security',
  },
  {
    id: '3',
    question: 'Can I integrate NexAI with my existing tools?',
    answer: 'Yes, NexAI offers 200+ native integrations with popular tools like Slack, Jira, GitHub, Salesforce, and more. We also provide a powerful API (REST and GraphQL) and webhook support for custom integrations.',
    category: 'product',
  },
  {
    id: '4',
    question: 'What kind of support do you offer?',
    answer: 'We offer tiered support plans. Starter plans include email support with 24-hour response. Professional plans include priority email and chat support. Enterprise plans include 24/7 dedicated support with a personal account manager.',
    category: 'billing',
  },
  {
    id: '5',
    question: 'How does pricing work?',
    answer: 'We offer flexible monthly and annual billing options. Annual plans save you 17% compared to monthly billing. All plans include a 14-day free trial with full access to features. No credit card required.',
    category: 'billing',
  },
  {
    id: '6',
    question: 'Can I upgrade my plan later?',
    answer: 'Yes, you can upgrade or downgrade your plan at any time. Upgrades take effect immediately, and we prorate the billing automatically. Downgrades apply from the next billing cycle.',
    category: 'billing',
  },
  {
    id: '7',
    question: 'Do you offer custom enterprise solutions?',
    answer: 'Yes, our Enterprise plan includes custom solutions tailored to your organization\'s needs. This includes custom integrations, dedicated infrastructure, custom analytics dashboards, and personalized onboarding.',
    category: 'enterprise',
  },
  {
    id: '8',
    question: 'How long does implementation take?',
    answer: 'Most teams are up and running within a day. Our intuitive interface and comprehensive documentation make onboarding seamless. Enterprise customers receive dedicated onboarding support to ensure smooth migration.',
    category: 'product',
  },
]