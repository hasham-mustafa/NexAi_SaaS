# NexAI – AI Platform Landing Page

A modern, interactive, and fully responsive AI SaaS landing page built with the latest React ecosystem. NexAI is a fictional AI platform designed to demonstrate production-ready frontend development, immersive user experiences, smooth animations, and scalable component architecture.

---

## Overview

NexAI is a single-page marketing website that combines modern UI/UX principles with advanced frontend technologies. It features interactive 3D elements, engaging animations, responsive layouts, dark/light theme support, multilingual capabilities, and performance-focused development.

The project showcases how a professional SaaS landing page can be built using React, TypeScript, and modern frontend tools while maintaining accessibility, maintainability, and scalability.

---

## Features

* Modern and responsive SaaS landing page
* Interactive Hero section with 3D visuals
* Smooth scrolling experience
* Advanced animations and transitions
* Dark & Light theme support
* Multi-language (i18n) support
* Fully responsive across all devices
* Accessible UI components
* Pricing plans section
* Product showcase
* Feature comparison section
* Customer testimonials
* Frequently Asked Questions (FAQ)
* Blog preview section
* Contact form with validation
* Animated statistics and counters
* Interactive sliders and carousels
* Progressive Web App (PWA) support
* Production-ready component architecture

---

## Tech Stack

### Frontend

* React 19
* TypeScript 6
* Vite 8
* Tailwind CSS 4

### Routing

* React Router DOM

### Animations

* Framer Motion
* GSAP
* Lottie React
* React CountUp
* Lenis (Smooth Scrolling)

### 3D Graphics

* Three.js
* @react-three/fiber
* @react-three/drei

### UI Components

* Radix UI
* Lucide React
* React Icons

### Forms & Validation

* React Hook Form
* Zod

### Utilities

* Class Variance Authority (CVA)
* clsx
* tailwind-merge

### Additional Features

* Swiper.js
* Progressive Web App (vite-plugin-pwa)
* Internationalization (i18n)

---

## Website Sections

* Hero
* Features
* Product Showcase
* Comparison
* Pricing
* Testimonials
* FAQ
* Blog
* Contact
* Footer

---

## Custom Hooks

* useInView
* useLenis
* useMediaQuery
* useMousePosition
* useScrollProgress

---

## Context API

* Theme Context (Dark / Light Mode)
* Language Context (Internationalization)

---

## Project Structure

```
src/
│
├── components/
├── sections/
├── hooks/
├── context/
├── animations/
├── data/
├── assets/
├── pages/
├── routes/
├── utils/
└── App.tsx
```

---

## Installation

Clone the repository

```bash
git clone <repository-url>
```

Navigate to the project

```bash
cd nexai
```

Install dependencies

```bash
npm install
```

Start the development server

```bash
npm run dev
```

Build for production

```bash
npm run build
```

Preview the production build

```bash
npm run preview
```

---

## Performance & Accessibility

* Responsive design
* Optimized assets
* Lazy loading
* Accessible UI components
* Smooth user interactions
* Modern component architecture
* Fast development with Vite
* PWA-ready configuration

---

## Learning Outcomes

This project strengthened my experience with:

* Modern React architecture
* TypeScript development
* Component-based UI design
* Advanced animations
* Three.js integration
* Responsive web development
* Performance optimization
* Accessibility best practices
* Reusable component design
* Modern frontend tooling

---

## Live Demo

https://nextai-three-lime.vercel.app/

---

## License

This project was created for learning, portfolio, and demonstration purposes.
